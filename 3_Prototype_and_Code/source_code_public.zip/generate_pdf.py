"""Generate the current two-page assignment solution from canonical saved outputs."""
import json
from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, PageBreak
from src import config

def create_solution_pdf(output_path=None):
    base=config.OUTPUT_DIR/'revised'
    rows=json.loads((base/'ranked/ranked_promos.json').read_text(encoding='utf-8'))
    manifest=json.loads((base/'run_manifest.json').read_text(encoding='utf-8'))
    path=Path(output_path or config.OUTPUT_DIR/'Kuku_FM_Solution_Doc.pdf')
    path.parent.mkdir(parents=True,exist_ok=True)
    styles=getSampleStyleSheet(); body=ParagraphStyle('Compact',parent=styles['BodyText'],fontSize=9,leading=11,spaceAfter=6)
    story=[]
    def text(t): story.append(Paragraph(t,body))
    def head(t): story.append(Paragraph(t,styles['Heading2']))
    story.append(Paragraph('Kuku FM - Find the Promos',styles['Title']))
    text('Zeeshan Mehmood | Problem 1 | Source-backed cuts and proposed posting order')
    head('Task and division of work')
    text('Find 20-60-second promos across a microdrama screenplay: a hook inside three seconds, an unresolved ending, and a scene understandable without prior episodes. The tool identifies cuts only; it adds no editing, music or overlays. Code handles parsing, stable source IDs, timestamps, duration, boundaries and overlap. Gemini proposes dramatic moments and judges subjective quality.')
    head('Pipeline and ranking')
    text('Parse scenes, actions and dialogue; discover moments; construct single-episode or ordered multi-segment clips by source ID; score; critique and validate; select a diverse shortlist. Models select IDs, never invent timecodes. Changed boundaries require rescoring and re-auditing. Weights: hook 30%, cliffhanger 25%, coherence 20%, emotion 15%, duration 10%. The saved order uses historical composite, hook and cliffhanger tie-breaks; weights are product assumptions.')
    head('Catalog result and execution status')
    text('50 episodes / 3,727 elements; 89 candidates; 15 saved recommendations across 14 episodes. All saved cuts pass 20-60-second and source timestamp checks, with no dialogue boundary crossings. The saved catalog is a cached replay: 268 responses, zero fresh API calls in that replay. Twelve changed clips without cached re-audits were excluded. A subsequent fresh full-pack attempt stopped at quota after 18 attempts / 15 successful calls; it did not replace the shortlist.')
    head('Which to post first, and why')
    for row in rows[:3]:
        p=row['promo']; seg=' + '.join(f"Ep{s['episode']} {s['start_time']}-{s['end_time']}" for s in p['segments'])
        text(f"<b>#{row['rank']} {p['promo_id']}</b> | {escape(seg)} | {p['total_duration_sec']:.1f}s<br/><b>Hook:</b> {escape(p['hook'])}<br/><b>Ending:</b> {escape(p['cliffhanger'])}<br/><b>Posting reason:</b> {escape(row['posting_rationale'])}")
    text('Full ordered segments, hook, ending, one-line rationale, posting reason and quality caveat for every recommendation: 2_Outputs/RANKED_PROMOS.md, ranked_promos.csv and ranked_promos.json. Scores are historical model judgments; descriptions were corrected without fresh scoring or reranking.')
    story.append(PageBreak())
    head('Where the tool picks badly')
    text('<b>Opening timing:</b> PR-027 claimed a shove inside three seconds; it occurs at +3.2s. Corrected hook: the thug orders "Get out of the way!" at +0.6s and Juliana refuses at +2.3s. PR-046 claimed "Stop this!" as the hook, but it begins at +3.9s. Its actual opening is a weak call to Rupert at +2.0s; it remains a low-priority pick.')
    text('<b>Payoff versus cliffhanger:</b> PR-016 reveals wounds, PR-041 names an attacker, PR-002 explains betrayal and PR-075 reveals authority. These may satisfy curiosity more than create a specific urgent future question. Their next-action questions are stated explicitly in the quality review; they are not certified strong cliffhangers. PR-008 and PR-027 more clearly withhold a confrontation outcome.')
    text('<b>Cold-viewer clarity:</b> PR-085 ends on an unclear agreement; PR-062 starts with "she" before naming the missing person; PR-070 uses "this" and "witch" with inferred referents. Multi-speaker and joined cuts increase context burden. Emotion annotations can fool the offline picker; a high score is not proof of a good promo.')
    text('<b>Descriptions:</b> PR-067 starts kneeling rather than standing; PR-070 is a profile shot, not direct camera address; PR-076 has a venomous delivery, not an established whisper. The corrected descriptions follow source evidence. Original model reasoning is retained as historical, with known errors disclosed.')
    head('Quality checks and evidence limits')
    text('Previous packaged evidence reports 47 offline stress checks and 67 regression cases. Balanced authored tests cover 12 endings (closure precision 0.80, recall 0.667), six hook-timing cases and six abstention controls. They expose missed implicit resolutions, a threatening phrase false alarm, and misleading emotions. These small development cases do not establish general creative quality. See the current verification report for checks rerun after this submission correction.')
    text('The baseline scorer is from the same model family. Unequal selection and shortlist ranking bias comparisons; neither all-candidate nor top-shortlist averages establish an advantage over episode endings. No audience or conversion lift is claimed. Human evaluation is optional and is not a missing assignment deliverable.')
    text('An external Romeo and Juliet excerpt produced two cuts using eight uncached calls without heuristic fallback. An unsupported "nervous whispering" description survived the auditor. Timings were estimated and the classic may be known to the model. Exact IDs and quotes verify inclusion, not every adjective, visual delivery or footage timing.')
    head('Run, inputs and scale')
    text('Extract source_code.zip; run <b>pip install -r requirements.txt</b>, then <b>streamlit run app.py</b>. Saved results need no key. Live Runner supports uploaded timestamped UTF-8 .txt scripts and explicit offline or Gemini extraction. Gemini needs GEMINI_API_KEY in .env and quota; model names are configurable. Other screenplay layouts, prose, PDFs and subtitles need adapters; malformed timed headers fail explicitly.')
    text('Original execution: 673 seconds and approximately $0.0934 at configured token-price assumptions; this is not verified billing and excludes retries in other runs, hosting and editor time. New shows require new extraction. Bounded concurrency, caching and quota-aware work queues are scale considerations. Script precision is not footage accuracy. Private archives contain Kuku-derived material; public code excludes outputs and credentials.')
    SimpleDocTemplate(str(path),pagesize=A4,leftMargin=36,rightMargin=36,topMargin=28,bottomMargin=28).build(story)
    return path

if __name__=='__main__': print(create_solution_pdf())
