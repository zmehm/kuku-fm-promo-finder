"""Run corrected full-pack pipeline and synthetic unseen-input checks; preserve original evidence."""
import json
import logging
from pathlib import Path
from src import config
from src.parser import parse_all_episodes, parse_episode, save_parsed_episodes
from src.pipeline import run_pipeline, save_result
from src.llm_client import GeminiClient, HeuristicClient
from src.quality_checker import validate_timestamps, total_duration
from test_revision import synthetic

logging.getLogger().setLevel(logging.WARNING)
original=config.OUTPUT_DIR
config.OUTPUT_DIR=original/"revised"
for key,folder in [("PARSED_DIR","parsed"),("MOMENTS_DIR","moments"),("PROMOS_DIR","promos"),("RANKED_DIR","ranked"),("QUALITY_DIR","quality_report"),("HUMAN_EVAL_DIR","human_eval")]:
    setattr(config,key,config.OUTPUT_DIR/folder)
# Existing responses are reusable only when prompt, model, and schema match.
config.ensure_output_dirs()
eps_list=parse_all_episodes(config.SCRIPTS_DIR)
save_parsed_episodes(eps_list,config.PARSED_DIR)
eps={e.episode_number:e for e in eps_list}
print("Parsed revised catalog:",len(eps),"episodes;",sum(e.total_elements for e in eps_list),"elements",flush=True)
cached_client=GeminiClient()
cached_client._client=None  # Explicit cache-only audit after observed API quota failure.
result=run_pipeline(eps,client=cached_client,run_baselines=True)
result.manifest["validation_mode"]="cache-only replay after Gemini 429 quota failure; missing responses use disclosed heuristics; trimmed candidates without cached re-audit are excluded"
save_result(result)
print("Revised full-pack run:",len(result.ranked),"shortlisted; cache hits",result.manifest["cache_hits"],flush=True)
assert len(eps)==50 and result.ranked
for row in result.ranked:
    assert 20<=total_duration(row.promo)<=60
    assert not validate_timestamps(row.promo,eps)
newdir=config.OUTPUT_DIR/"unseen_validation"
newdir.mkdir(exist_ok=True)
path=newdir/"synthetic_space_rescue.txt"
path.write_text(synthetic(),encoding="utf-8")
ep=parse_episode(path)
live=run_pipeline({ep.episode_number:ep},client=HeuristicClient(),run_baselines=False)
assert live.ranked
for row in live.ranked:
    assert 20<=total_duration(row.promo)<=60
    assert not validate_timestamps(row.promo,{ep.episode_number:ep})
(newdir/"results.json").write_text(json.dumps({"test_scope":"Synthetic story outside original show, same timestamped format; offline heuristic validation only. Fresh Gemini validation was blocked by account quota (429). Not a real unseen-show marketing-quality evaluation.","manifest":live.manifest,"ranked":[r.model_dump() for r in live.ranked]},indent=2),encoding="utf-8")
print("Synthetic offline check:",len(live.ranked),"shortlisted; fallbacks",live.manifest["fallback_to_heuristic"],flush=True)
