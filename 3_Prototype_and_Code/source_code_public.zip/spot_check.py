"""Read-only checks on corrected submission artifacts."""
import json
from pathlib import Path
from pypdf import PdfReader
from src import config
from src.schemas import RankedPromo, ParsedEpisode
from src.quality_checker import validate_timestamps,total_duration,validate_ad_policy
base=config.OUTPUT_DIR/"revised"
eps={}
for f in (base/"parsed").glob("episode-*.json"):
    ep=ParsedEpisode.model_validate_json(f.read_text(encoding="utf-8")); eps[ep.episode_number]=ep
rows=[RankedPromo.model_validate(x) for x in json.loads((base/"ranked/ranked_promos.json").read_text(encoding="utf-8"))]
assert len(eps)==50 and sum(e.total_elements for e in eps.values())==3727
assert len(rows)==15
for row in rows:
    assert 20<=total_duration(row.promo)<=60
    assert not validate_timestamps(row.promo,eps)
    assert not any(f.severity.value=="high" for f in validate_ad_policy(row.promo,eps))
assert [r.scores.composite for r in rows]==sorted([r.scores.composite for r in rows],reverse=True)
assert len(PdfReader(config.OUTPUT_DIR/"Kuku_FM_Solution_Doc.pdf").pages)==2
print("PASS: 50 episodes, 3727 elements, 15 sorted valid promos, no hard risk hits, 2-page PDF.")
