import json
from pathlib import Path
import pytest
from src import config
from src.parser import parse_episode
from src.pipeline import run_pipeline
from src.llm_client import HeuristicClient,GeminiClient
from src.evidence import verify_evidence,provenance
from quality_checks import simple_promo,scene_text,confusion,suite,register,registered,BoundedClient
from test_revision import synthetic


@pytest.fixture
def episode(tmp_path):
    path=tmp_path/'scene.txt';path.write_text(synthetic(),encoding='utf-8');return parse_episode(path)


def valid_judgment():
    return {'hook_supported':True,'ending_unresolved':True,'standalone_clear':True,'unresolved_question':'Who is inside the sealed cabin and who is beside the captain?','hook_support':[{'element_id':'901.001','quote':'The rescue signal is coming from inside our ship!'}],'ending_support':[{'element_id':'901.008','quote':'Three knocks echo from the sealed cabin.'}],'reason':'A mysterious signal opens the scene and the sealed cabin remains unexplained.'}


def promo(ep):
    from test_hardening import make_promo
    return make_promo(ep)


def test_evidence_accepts_cited_source_windows(episode):
    audit=verify_evidence(promo(episode),{901:episode},valid_judgment())
    assert audit['passed']
    assert 'model judgments' in audit['grounding_scope']


@pytest.mark.parametrize('change',["invented_id","invented_quote","delayed_hook","missing_question","resolved","missing_support","unclear_context"])
def test_invalid_or_unsupported_evidence_is_rejected(episode,change):
    j=valid_judgment()
    if change=='invented_id': j['hook_support'][0]['element_id']='901.999'
    elif change=='invented_quote': j['hook_support'][0]['quote']='This line never appeared in the script.'
    elif change=='delayed_hook': j['hook_support']=[{'element_id':'901.002','quote':'That cabin has been sealed for twenty years.'}]
    elif change=='missing_question': j['unresolved_question']=''
    elif change=='resolved': j['ending_unresolved']=False
    elif change=='missing_support': j['ending_support']=[]
    else: j['standalone_clear']=False
    assert not verify_evidence(promo(episode),{901:episode},j)['passed']


def test_flat_scene_can_abstain_without_exception(tmp_path):
    path=tmp_path/'flat.txt';text=scene_text('Have a good afternoon.',first='Good morning.')
    for old,new in [('Let me see the letter.','Here is your tea.'),('That signature is not mine.','Thank you.'),('Someone is standing outside.','Please sit down.'),('We need to decide now.','It is a pleasant day.')]: text=text.replace(old,new)
    path.write_text(text,encoding='utf-8');ep=parse_episode(path)
    result=run_pipeline({ep.episode_number:ep},client=HeuristicClient(),run_baselines=True)
    assert not result.ranked and not result.candidates
    assert result.manifest['status']=='abstained_no_candidates'
    assert result.report.total_candidates_generated==0


def test_empty_ai_moments_are_not_falsely_called_an_api_failure(episode):
    from src.schemas import EpisodeMoments
    class Empty(GeminiClient):
        def identify_moments(self,ep): return EpisodeMoments(episode_number=ep.episode_number,moments=[])
        def construct_episode_promos(self,*args): return []
    client=Empty(use_cache=False);client._client=None
    result=run_pipeline({901:episode},client=client,run_baselines=False)
    assert result.manifest['fallback_to_heuristic']['moments']==[]
    assert result.manifest['status']=='abstained_no_candidates'


def test_balanced_scorecard_retains_both_misses_and_false_alarms(tmp_path):
    result=suite(tmp_path/'suite')
    assert result['closure']['metrics']['n']==12
    m=result['closure']['metrics']
    assert m['true_positive']+m['false_negative']==6
    assert m['false_positive']+m['true_negative']==6
    assert len(result['closure']['cases'])==12
    assert result['delayed_hook']['metrics']['recall']==1
    m=result['offline_abstention']['metrics']
    assert m['true_positive']+m['false_negative']==3
    assert m['false_positive']+m['true_negative']==3


def test_metrics_count_negative_controls():
    rows=[{'truth':True,'detected':True},{'truth':True,'detected':False},{'truth':False,'detected':True},{'truth':False,'detected':False}]
    assert confusion(rows)=={'true_positive':1,'false_positive':1,'false_negative':1,'true_negative':1,'precision':0.5,'recall':0.5,'false_positive_rate':0.5,'n':4}


def test_provenance_is_stable_and_tracks_runtime(episode,monkeypatch):
    a=provenance({901:episode});b=provenance({901:episode})
    assert a['fingerprint']==b['fingerprint']
    assert 'src/evidence.py' in a['code_sha256']
    monkeypatch.setattr(config,'GEMINI_MODEL','different-model')
    assert provenance({901:episode})['fingerprint']!=a['fingerprint']


def test_registration_is_immutable_and_detects_changed_input(tmp_path):
    path=tmp_path/'challenge.txt';path.write_text(synthetic(),encoding='utf-8');record=tmp_path/'record.json'
    data=register(path,record,'development')
    assert 'not held-out' in data['independence']
    with pytest.raises(ValueError,match='already exists'): register(path,record,'development')
    path.write_text(synthetic().replace('captain','commander'),encoding='utf-8')
    with pytest.raises(ValueError,match='changed'): registered(record,tmp_path/'result')


def test_quota_circuit_stops_additional_calls(monkeypatch):
    calls=[]
    def quota(self,*args,**kwargs): calls.append(1);raise RuntimeError('429 RESOURCE_EXHAUSTED')
    monkeypatch.setattr(GeminiClient,'generate',quota)
    client=BoundedClient()
    with pytest.raises(RuntimeError): client.generate('first')
    with pytest.raises(RuntimeError): client.generate('second')
    assert client.blocked_reason=='api_quota' and len(calls)==1


def test_call_budget_is_enforced_without_network():
    client=BoundedClient(max_calls=0)
    with pytest.raises(RuntimeError,match='budget'): client.generate('no network')
    assert client.attempted_calls==0
