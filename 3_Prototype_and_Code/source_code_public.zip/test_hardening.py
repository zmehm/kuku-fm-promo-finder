from pathlib import Path
import pytest
from src import config
from src.parser import parse_episode,parse_all_episodes,normalize_timestamp
from src.clips import render_clip_text,render_episode_for_llm
from src.quality_checker import validate_timestamps,validate_ending_claim,validate_resolution_cues
from src.llm_client import GeminiClient
from test_revision import synthetic
from src.schemas import PromoCandidate,PromoSegment

def make_promo(ep,end=48):
    return PromoCandidate(promo_id="TEST",promo_type="single_episode",episodes=[901],segments=[PromoSegment(episode=901,start_time="00:00.00",end_time=f"00:{end:02d}.00",start_seconds=0,end_seconds=end)],hook="A captain receives a mysterious signal",cliffhanger="An unexplained presence waits beyond the hatch",why_it_works="A clear mystery leaves the outcome unresolved for the viewer.")


@pytest.fixture
def episode(tmp_path):
    path=tmp_path/'episode-901.txt';path.write_text(synthetic(),encoding='utf-8')
    return parse_episode(path)


@pytest.mark.parametrize('timestamp',['00:60.00','00:99.00','99:99.99'])
def test_invalid_clock_rejected(timestamp):
    with pytest.raises(ValueError,match='seconds'): normalize_timestamp(timestamp)


def test_fraction_rounding_carries_valid_clock():
    assert normalize_timestamp('00:59.999')=='01:00.00'
    with pytest.raises(ValueError,match='99-minute'): normalize_timestamp('99:59.999')


@pytest.mark.parametrize('replacement',[
    'Start: (00:08.00) | End: (00:06.00)',
    'Start: (00:00.00) | End: (00:00.00)',
    'Start: (broken) | End: (00:06.00)',
    '',
])
def test_corrupt_block_fails_instead_of_partial_parse(tmp_path,replacement):
    path=tmp_path/'episode-901.txt'
    path.write_text(synthetic().replace('Start: (00:00.00) | End: (00:06.00)',replacement,1),encoding='utf-8')
    with pytest.raises(ValueError): parse_episode(path)


def test_duplicate_content_rejected(tmp_path):
    path=tmp_path/'episode-901.txt';path.write_text(synthetic()+'\n'+synthetic(),encoding='utf-8')
    with pytest.raises(ValueError,match='Multiple episode headers'): parse_episode(path)


def test_catalog_does_not_silently_drop_bad_episode(tmp_path):
    (tmp_path/'episode-901.txt').write_text(synthetic(),encoding='utf-8')
    (tmp_path/'episode-902.txt').write_text('broken episode',encoding='utf-8')
    with pytest.raises(ValueError,match='no partial catalog accepted'): parse_all_episodes(tmp_path)


@pytest.mark.parametrize('field,value',[('start_time','00:12.00'),('end_time','00:47.00'),('end_seconds',float('nan'))])
def test_inconsistent_or_nonfinite_coordinates_are_hard_failures(episode,field,value):
    promo=make_promo(episode);setattr(promo.segments[0],field,value)
    flags=validate_timestamps(promo,{901:episode})
    assert flags and all(f.severity.value=='high' for f in flags)


def test_internal_repeat_rejected_but_adjacent_allowed(episode):
    promo=make_promo(episode);seg=promo.segments[0];seg.end_seconds=24;seg.end_time='00:24.00'
    promo.segments=[seg,seg.model_copy(deep=True)]
    assert validate_timestamps(promo,{901:episode})
    promo.segments[1].start_seconds=24;promo.segments[1].start_time='00:24.00'
    promo.segments[1].end_seconds=48;promo.segments[1].end_time='00:48.00'
    assert not validate_timestamps(promo,{901:episode})


def test_long_line_reaches_both_model_renderers(episode):
    episode.scenes[0].elements[0].content='A'*1000+' CRITICAL_REVEAL'
    assert 'CRITICAL_REVEAL' in render_episode_for_llm(episode)
    assert 'CRITICAL_REVEAL' in render_clip_text(make_promo(episode),{901:episode})


def test_oversized_model_input_fails_before_network(monkeypatch):
    monkeypatch.setattr(config,'LLM_MAX_INPUT_CHARS',10)
    client=GeminiClient(use_cache=False);client._client=None
    with pytest.raises(ValueError,match='not silently truncated'): client.generate('X'*11)


def test_stale_cliffhanger_claim_not_mislabelled_semantic_resolution(episode):
    promo=make_promo(episode);promo.cliffhanger='Ends on: "The rescue signal is coming from inside our ship!"'
    flags=validate_ending_claim(promo,{901:episode})
    assert flags and flags[0].failure_type.value=='hallucinated_claim'
    assert 'not evidence that suspense is resolved' in flags[0].explanation


@pytest.mark.parametrize('ending',["It is over. We are safe now.","The case is closed."])
def test_explicit_closure_is_editor_review_hint(episode,ending):
    episode.scenes[0].elements[-2].content=ending
    flags=validate_resolution_cues(make_promo(episode,42),{901:episode})
    assert flags and flags[0].severity.value=='medium'
    assert flags[0].failure_type.value=='resolved_cliffhanger'


@pytest.mark.parametrize('ending',["We are not safe now.","We are safe now. But look behind you!","Is it over?"])
def test_negated_or_new_threat_is_not_closure(episode,ending):
    episode.scenes[0].elements[-2].content=ending
    assert not validate_resolution_cues(make_promo(episode,42),{901:episode})
