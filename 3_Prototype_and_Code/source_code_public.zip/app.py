"""
app.py — Interactive Streamlit Dashboard for Kuku FM Promo Finder.

Allows performance marketing editors and executives to:
1. Inspect ranked promo recommendations with 0.01s script precision.
2. View script context side-by-side with promo moments.
3. Review quality auditor flags, failure taxonomy, and baseline comparisons.
4. Test creative angles (Betrayal, Romance, Identity, Thriller) for ad rotation.
5. Run live analysis on new scripts for the interview demo.
"""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import streamlit as st

from src import config
from src.clips import render_clip_text
from src.parser import parse_all_episodes, parse_episode
from review_tools import cut_sheet, sheet_markdown
import io
import zipfile
from src.evidence import audit_evidence
from src.pipeline import run_pipeline
from src.llm_client import GeminiClient, HeuristicClient
from src.schemas import ParsedEpisode
import tempfile
from src.schemas import RankedPromo

# Configure page
st.set_page_config(
    page_title="Kuku FM | AI Promo Finder",
    page_icon="🎬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ──────────────────────────────────────────────────────────────────────
# DATA LOADERS (Cached)
# ──────────────────────────────────────────────────────────────────────

@st.cache_data
def load_data():
    base = config.OUTPUT_DIR / "revised" if (config.OUTPUT_DIR / "revised" / "run_manifest.json").exists() else config.OUTPUT_DIR
    ranked_path = base / "ranked" / "ranked_promos.json"
    quality_path = base / "quality_report" / "quality_report.json"
    manifest_path = base / "run_manifest.json"
    human_path = config.HUMAN_EVAL_DIR / "human_eval_results.json"

    ranked = json.loads(ranked_path.read_text(encoding="utf-8")) if ranked_path.exists() else []
    quality = json.loads(quality_path.read_text(encoding="utf-8")) if quality_path.exists() else {}
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
    human = json.loads(human_path.read_text(encoding="utf-8")) if human_path.exists() else {}

    episodes = {}
    if (base / "parsed").exists():
        for p in sorted((base / "parsed").glob("episode-*.json")):
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                episodes[data["episode_number"]] = data
            except Exception:
                pass

    return ranked, quality, manifest, human, episodes


ranked_data, quality_data, manifest_data, human_data, parsed_episodes = load_data()
if manifest_data.get("validation_mode"):
    st.info(manifest_data["validation_mode"])

# ──────────────────────────────────────────────────────────────────────
# SIDEBAR
# ──────────────────────────────────────────────────────────────────────

with st.sidebar:
    st.title("🎬 Promo Finder Engine")
    st.caption("AI-Powered Microdrama UA Optimization")

    st.markdown("---")
    st.markdown("**Show:** *I Married a Broken Soldier. He was a Duke*")
    st.markdown(f"**Parsed Episodes:** {len(parsed_episodes)} / 50")
    st.markdown(f"**Shortlist Promos:** {len(ranked_data)}")
    st.markdown(f"**Model:** `{manifest_data.get('model', config.GEMINI_MODEL)}`")

    st.markdown("---")
    st.subheader("Performance Funnel Weights")
    for k, v in config.SCORING_WEIGHTS.items():
        st.markdown(f"- **{k.replace('_', ' ').title()}:** {int(v*100)}%")

    st.markdown("---")
    st.info("💡 **Interview Demo Ready**: Navigate to the 'Live Runner' tab to analyze any episode script in real time.")


# ──────────────────────────────────────────────────────────────────────
# MAIN HEADER & KPI CARDS
# ──────────────────────────────────────────────────────────────────────

st.title("🎬 Kuku FM Promo Discovery & Ranking Engine")
st.markdown(
    "Automating promo clip discovery from microdrama screenplays. Eliminates manual scrubbing bottlenecks "
    "with source-based checks for opening hooks, unresolved endings and standalone clarity."
)

c1, c2, c3, c4, c5 = st.columns(5)
with c1:
    st.metric("Episodes Analyzed", manifest_data.get("n_episodes", len(parsed_episodes)))
with c2:
    st.metric("Shortlist Promos", len(ranked_data))
with c3:
    mean_score = quality_data.get("mean_composite_score", 0)
    st.metric("Historical Model Score", f"{mean_score:.2f}/10")
with c4:
    flags_count = quality_data.get("total_flagged", 0)
    st.metric("Quality Flags", flags_count, "Self-Audited")
with c5:
    cost_usd = manifest_data.get("live_api_usage", manifest_data.get("cost", {})).get("estimated_cost_usd", 0)
    st.metric("Estimated API Cost", f"${cost_usd:.4f}", f"{manifest_data.get('live_api_usage', manifest_data.get('cost', {})).get('total_api_calls', 0)} calls")


# ──────────────────────────────────────────────────────────────────────
# TABS
# ──────────────────────────────────────────────────────────────────────

tab1, tab2, tab3, tab4 = st.tabs([
    "🏆 Top Ranked Promos",
    "🔍 Quality Auditor & Failure Modes",
    "📊 Business & Baseline Analytics",
    "⚡ Live Script Runner (Interview Demo)",
])

# ── TAB 1: RANKED PROMOS ───────────────────────────────────────────────
with tab1:
    st.subheader("Curated Promo Shortlist — Ready for Video Editors")

    f1, f2, f3 = st.columns([2, 2, 2])
    with f1:
        creative_filter = st.selectbox(
            "Filter by Marketing Angle",
            ["All Angles", "betrayal_revenge", "protective_romance", "hidden_identity", "survival_thriller"],
        )
    with f2:
        promo_type_filter = st.selectbox(
            "Filter by Format",
            ["All Formats", "single_episode", "cross_episode", "multi_segment"],
        )
    with f3:
        min_score = st.slider("Minimum Composite Score", 4.0, 10.0, 6.0, 0.1)

    filtered_promos = []
    for item in ranked_data:
        p = item["promo"]
        score = item["scores"]["composite"]
        angle = p.get("creative_angle") or "general"
        ptype = p.get("promo_type") or "single_episode"

        if score < min_score:
            continue
        if creative_filter != "All Angles" and angle != creative_filter:
            continue
        if promo_type_filter != "All Formats" and ptype != promo_type_filter:
            continue
        filtered_promos.append(item)

    st.caption(f"Showing {len(filtered_promos)} matching promos")

    for item in filtered_promos:
        promo = item["promo"]
        scores = item["scores"]
        rank = item["rank"]
        promo_id = promo["promo_id"]
        episodes_list = promo["episodes"]
        duration = promo["total_duration_sec"]
        composite = scores["composite"]
        angle = promo.get("creative_angle", "general")
        ptype = promo.get("promo_type", "single_episode")

        rank_badge = "🥇" if rank == 1 else ("🥈" if rank == 2 else ("🥉" if rank == 3 else f"#{rank}"))

        with st.container(border=True):
            col_header, col_score = st.columns([4, 1])
            with col_header:
                st.markdown(f"### {rank_badge} **{promo_id}** — Ep {', '.join(str(e) for e in episodes_list)} ({duration:.1f}s)")
                st.caption(f"**Format:** `{ptype}` | **Angle:** `{angle.replace('_', ' ').title()}` | **Rationale:** {item.get('posting_rationale', 'Primary creative pick')}")
            with col_score:
                st.metric("Historical Model Score", f"{composite:.2f}/10")

            st.markdown("**Timestamps & Segments:**")
            seg_cols = st.columns(len(promo["segments"]))
            for idx, seg in enumerate(promo["segments"]):
                with seg_cols[idx]:
                    dur_seg = seg["end_seconds"] - seg["start_seconds"]
                    st.code(f"Ep {seg['episode']} | {seg['start_time']} ➔ {seg['end_time']}\nDuration: {dur_seg:.1f}s", language="text")

            c_hook, c_cliff = st.columns(2)
            with c_hook:
                st.markdown("🪝 **The Hook (First 0–3s):**")
                st.info(promo["hook"])
            with c_cliff:
                st.markdown("⏳ **The Cliffhanger (Cut Point):**")
                st.warning(promo["cliffhanger"])

            st.markdown(f"💡 **Why It Works:** {promo['why_it_works']}")

            if item.get("quality_review"):
                review = item["quality_review"]
                st.markdown("**Unresolved question:** " + review["unresolved_question"])
                st.warning("Quality caveat: " + review["caveat"])
                st.caption(review["score_status"])

            if all(ep in parsed_episodes for ep in promo["episodes"]):
                evidence = cut_sheet(RankedPromo.model_validate(item), {ep: ParsedEpisode.model_validate(parsed_episodes[ep]) for ep in promo["episodes"]})
                with st.expander("Source evidence: first 3 seconds, ending, and boundary review"):
                    st.markdown("**Opening evidence (overlaps first 3 seconds)**")
                    for beat in evidence["first_3_seconds"]:
                        st.write(f"+{beat['offset_start']:.2f}s: {beat['text']}")
                    st.markdown("**Ending evidence (overlaps last 5 seconds)**")
                    for beat in evidence["last_5_seconds"]:
                        st.write(f"+{beat['offset_start']:.2f}s: {beat['text']}")
                    if evidence["dialogue_crossing_boundaries"]:
                        st.warning("Some dialogue overlaps a cut boundary. Review the source before posting.")
                        st.json(evidence["dialogue_crossing_boundaries"])
                    else:
                        st.caption("No dialogue crosses these boundaries in parsed script data. Footage review is still required.")
                    st.code(evidence["source_text"], language="text")
                st.download_button("Download editor cut sheet", sheet_markdown(evidence), file_name=f"{promo_id}_cut_sheet.md", mime="text/markdown", key=f"cut_{promo_id}")
            if item.get("evidence_audit"):
                st.caption("Source-evidence audit available: IDs, exact quotes and script windows checked; semantic quality remains a model assessment.")
                with st.expander("Cited hook and unresolved-question evidence"):
                    st.json(item["evidence_audit"])
            else:
                st.caption("Historical recommendation: no new source-citation audit is claimed for this saved score.")

            with st.expander("📊 View Detailed Scoring Breakdown"):
                sc1, sc2, sc3, sc4, sc5 = st.columns(5)
                sc1.metric("Hook (30%)", f"{scores['hook_strength']}/10")
                sc2.metric("Cliffhanger (25%)", f"{scores['cliffhanger_quality']}/10")
                sc3.metric("Standalone (20%)", f"{scores['standalone_coherence']}/10")
                sc4.metric("Emotion (15%)", f"{scores['emotional_impact']}/10")
                sc5.metric("Duration (10%)", f"{scores['duration_fitness']}/10")
                if item.get("score_reasoning"):
                    st.caption(f"**LLM Judge Reasoning:** {item['score_reasoning']}")


# ── TAB 2: QUALITY AUDITOR & FAILURES ──────────────────────────────────
with tab2:
    st.subheader("Quality Assurance & Failure Taxonomy")
    st.markdown(
        "A production pipeline must self-audit and flag fragile picks before they reach video editors. "
        "Every candidate receives deterministic rule checks; adversarial critique covers the configured top candidates when enabled."
    )

    q1, q2 = st.columns([1, 1])
    with q1:
        st.markdown("### 🛑 Verified Failure Breakdown")
        breakdown = quality_data.get("failure_breakdown", {})
        if breakdown:
            st.dataframe(pd.DataFrame([{"Failure Type": k.replace("_", " ").title(), "Flags Count": v} for k, v in breakdown.items()]), hide_index=True, use_container_width=True)

    with q2:
        st.markdown("### 📈 Baseline Benchmark Comparison")
        b_dict = quality_data.get("baseline_comparison", {})
        if b_dict:
            b_df = pd.DataFrame([{"Strategy": k.replace("_", " ").title(), "Avg Composite (1-10)": v} for k, v in b_dict.items()])
            st.dataframe(b_df, hide_index=True, use_container_width=True)

    st.markdown("---")
    st.subheader("⚠️ Self-Audited Quality Flags (Real Run Logs)")

    flags = quality_data.get("flags", [])
    if flags:
        for f in flags:
            with st.container(border=True):
                sev_color = "red" if f["severity"] == "high" else ("orange" if f["severity"] == "medium" else "blue")
                st.markdown(f"**Promo:** `{f['promo_id']}` | **Type:** `:{sev_color}[{f['failure_type'].upper()}]` | **Severity:** `{f['severity'].upper()}`")
                st.markdown(f"**Audit Finding:** {f['explanation']}")
                st.markdown(f"**Recommended Action:** `{f['suggested_fix']}`")


# ── TAB 3: BUSINESS & BASELINE ANALYTICS ────────────────────────────────
with tab2:
    st.subheader("Balanced development quality checks")
    scorecard_path=config.OUTPUT_DIR / "quality_checks" / "development_v1" / "scorecard.json"
    if scorecard_path.exists():
        scorecard=json.loads(scorecard_path.read_text(encoding="utf-8"))
        st.caption(scorecard["scope"])
        data=[]
        for label in ["closure","delayed_hook","offline_abstention"]:
            metrics=scorecard[label]["metrics"]
            data.append({"Check":label.replace("_"," "),"Cases":metrics["n"],"Correct flags":metrics["true_positive"],"False alarms":metrics["false_positive"],"Misses":metrics["false_negative"],"Correct controls":metrics["true_negative"]})
        st.table(pd.DataFrame(data))
        with st.expander("Inspect all expected and detected outcomes"):
            st.json(scorecard)
    attempt_path=config.OUTPUT_DIR / "quality_checks" / "latest_attempt_summary.json"
    if attempt_path.exists():
        attempt=json.loads(attempt_path.read_text(encoding="utf-8"))
        st.warning(f"Final-version fresh run: {attempt['status']}. {attempt.get('reason','')}")
        st.caption("A quota-blocked evidence audit is unavailable, not a semantic rejection. Historical recommendations have not been relabelled as final-version AI results.")
        st.json(attempt,expanded=False)
    external_path=config.OUTPUT_DIR / "external_validation" / "romeo_first_scene_v1" / "summary.json"
    if external_path.exists():
        external=json.loads(external_path.read_text(encoding="utf-8"))
        st.markdown("**First independently authored external-source test**")
        st.info(f"Status: {external['status']}; {external['final_recommendations']} recommendations. Public-domain play excerpt; estimated timing only.")
        st.caption("No cached responses or heuristic fallback. Both cuts passed mechanical source checks. One unsupported delivery modifier survived the model audit; creative effectiveness is unmeasured. The public classic may be present in model training.")
        with st.expander("External-input provenance and limitations"):
            st.json(external)

    st.caption("Independent-input protocol: quality_checks.py register freezes a supplied script and source hashes; registered runs reject changed inputs/code. Input independence must be honestly supplied, not inferred from a filename.")


with tab3:
    st.subheader("Ranking basis and operational limits")
    st.write("Saved ranking uses historical model scores: hook 30%, cliffhanger 25%, coherence 20%, emotion 15%, duration 10%. Source descriptions were corrected without new model scores. This is a proposed posting order, not measured audience preference.")
    st.write("Baseline comparisons use the same model family and unequal candidate selection. They do not establish a performance advantage. The full-catalog fresh run stopped at quota; the saved shortlist is cached replay evidence.")
    st.caption("Original 50-episode run: 673 seconds and approximately $0.0934 under configured token-price assumptions. This excludes editor time, hosting and evaluation. Future costs depend on model, retries, input size and quota.")
    if st.button("Generate current solution PDF", disabled=not ranked_data):
        from generate_pdf import create_solution_pdf
        pdf_path=create_solution_pdf()
        st.download_button("Download solution PDF",pdf_path.read_bytes(),file_name=pdf_path.name,mime="application/pdf")


with tab4:
    st.subheader("⚡ Live Interview Demonstration Runner")
    st.markdown(
        "Demonstrates real-time live execution on a new script in the supported timestamped format to satisfy the interview brief: "
        "*'If you're shortlisted, you'll run your solution on a new input during your interview.'*"
    )

    st.caption("Supported input: UTF-8 .txt with an episode number, timestamped scenes, and ACTION / dialogue blocks like the supplied screenplay. Plain prose, PDF, subtitles, and other formats need an adapter.")
    mode = st.radio("Extraction mode", ["Offline heuristic (no API)", "Gemini AI (requires GEMINI_API_KEY)"])
    uploaded_file = st.file_uploader("Upload New Screenplay (.txt)", type=["txt"])
    selected_ep = None
    if not uploaded_file:
        selected_ep = st.selectbox("Or select an existing episode", sorted(parsed_episodes) or [1])
    if st.button("Run fresh promo extraction", type="primary"):
        try:
            if uploaded_file:
                with tempfile.TemporaryDirectory(prefix="promo_upload_") as upload_dir:
                    upload_path = Path(upload_dir) / "uploaded.txt"
                    upload_path.write_text(uploaded_file.getvalue().decode("utf-8-sig"), encoding="utf-8")
                    live_ep = parse_episode(upload_path)
            elif selected_ep in parsed_episodes:
                live_ep = ParsedEpisode.model_validate(parsed_episodes[selected_ep])
            else:
                raise ValueError("Upload a screenplay first; no saved episode is available.")
            client = HeuristicClient() if mode.startswith("Offline") else GeminiClient(use_cache=False)
            if isinstance(client, GeminiClient) and not client.available:
                raise ValueError("Set GEMINI_API_KEY in .env and restart, or select offline heuristic mode.")
            with st.spinner("Finding, scoring, and auditing new candidates..."):
                res = run_pipeline({live_ep.episode_number: live_ep}, client=client, run_baselines=False)
                if isinstance(client,GeminiClient):
                    checked=[];unavailable=0
                    for row in res.ranked:
                        try:
                            evidence=audit_evidence(client,row.promo,{live_ep.episode_number:live_ep})
                            if evidence["passed"]:
                                row.evidence_audit=evidence;row.rank=len(checked)+1;checked.append(row)
                        except Exception:
                            unavailable+=1
                    res.manifest["pre_evidence_shortlist_size"]=len(res.ranked)
                    res.manifest["evidence_unavailable"]=unavailable
                    res.ranked=checked
                    res.manifest["shortlist_size"]=len(checked)
                    res.manifest["cost"]=client.cost_tracker.model_dump()
                    res.manifest["live_api_usage"]=client.live_cost_tracker.model_dump()

            st.session_state["live_result"] = (res, live_ep)
        except (ValueError, UnicodeError) as exc:
            st.error(str(exc))
        except Exception as exc:
            st.error(f"Extraction failed: {exc}")
    if "live_result" in st.session_state:
        res, live_ep = st.session_state["live_result"]
        if res.ranked:
            st.success(f"Found {len(res.ranked)} shortlisted promos in {res.manifest['mode']} mode.")
        else:
            st.warning("No accepted recommendation. Review quota/audit availability and the suitability of the scene; this is not a successful promo selection.")
        st.caption("Heuristic results are approximate. Review hooks, cliffhangers, and cut points before use. Risk screening is heuristic and does not establish platform ad compliance.")
        st.json({"fallbacks": res.manifest["fallback_to_heuristic"], "cost": res.manifest["cost"], "evidence_unavailable": res.manifest.get("evidence_unavailable",0), "run_status":res.manifest.get("status")}, expanded=False)
        for rp in res.ranked:
            p = rp.promo
            st.markdown(f"### {p.promo_id} ({rp.scores.composite:.2f}/10)")
            for segment in p.segments:
                st.write(f"Episode {segment.episode}: {segment.start_time} - {segment.end_time}")
            st.write(f"Hook: {p.hook}")
            st.write(f"Cliffhanger: {p.cliffhanger}")
            st.write(p.why_it_works)
            if rp.evidence_audit:
                st.json(rp.evidence_audit)
            st.code(render_clip_text(p, {live_ep.episode_number: live_ep}), language="text")
