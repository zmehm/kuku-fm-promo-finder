"""Rebuild the current submission and combined ZIP from the canonical artifacts."""
from pathlib import Path
import argparse,json,zipfile,shutil
from generate_pdf import create_solution_pdf
from verify_submission import verify
from review_tools import load_artifacts,cut_sheet,sheet_markdown

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--submission',type=Path,required=True);parser.add_argument('--archive',type=Path,required=True);args=parser.parse_args()
    root=Path(__file__).resolve().parent;submit=args.submission.resolve()
    if args.archive.resolve().is_relative_to(submit): raise ValueError('Combined archive must be outside submission folder')
    create_solution_pdf();verify()
    base=root/'outputs/revised';review=root/'outputs/editor_review';cuts=review/'cut_sheets';cuts.mkdir(parents=True,exist_ok=True)
    eps,rows=load_artifacts(base);sheets=[cut_sheet(r,eps) for r in rows]
    for s in sheets: (cuts/(s['promo_id']+'.md')).write_text(sheet_markdown(s),encoding='utf-8')
    (cuts/'cut_sheets.json').write_text(json.dumps(sheets,indent=2),encoding='utf-8')
    evidence='# Five-clip source evidence\n\nSource-backed description corrections; no human evaluation requirement. Scores remain historical.\n\n'+'\n\n---\n\n'.join(sheet_markdown(s) for s in sheets[:5])
    (review/'five_clip_review.md').write_text(evidence,encoding='utf-8')
    for folder in ['1_Solution_Doc','2_Outputs','3_Prototype_and_Code','4_Review_and_Walkthrough','6_Quality_Checking']:(submit/folder).mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/'outputs/Kuku_FM_Solution_Doc.pdf',submit/'1_Solution_Doc/Kuku_FM_Solution_Doc.pdf')
    for source,name in [('ranked/ranked_promos.json','ranked_promos.json'),('ranked/ranked_promos.csv','ranked_promos.csv'),('quality_report/quality_report.json','quality_report.json'),('run_manifest.json','run_manifest.json'),('RANKED_PROMOS.md','RANKED_PROMOS.md'),('QUALITY_REVIEW.md','QUALITY_REVIEW.md')]:shutil.copy2(base/source,submit/'2_Outputs'/name)
    for name in ['WALKTHROUGH_GUIDE.md','NEXT_STEPS.md','QUALITY_CHECKING.md']:shutil.copy2(root/name,submit/'4_Review_and_Walkthrough'/name)
    shutil.copy2(review/'five_clip_review.md',submit/'4_Review_and_Walkthrough/five_clip_review.md')
    shutil.copy2(root/'QUALITY_CHECKING.md',submit/'6_Quality_Checking/QUALITY_CHECKING.md')
    shutil.copy2(root/'outputs/submission_revision_verification.json',submit/'6_Quality_Checking/submission_revision_verification.json')
    (submit/'README_SUBMISSION_WALKTHROUGH.txt').write_text((root/'README.md').read_text(encoding='utf-8'),encoding='utf-8')
    (submit/'3_Prototype_and_Code/PROTOTYPE_RUN_INSTRUCTIONS.txt').write_text((root/'README.md').read_text(encoding='utf-8'),encoding='utf-8')
    (submit/'START_HERE.txt').write_text('KUKU FM - FIND THE PROMOS | Zeeshan Mehmood\n\n1. Read 1_Solution_Doc/Kuku_FM_Solution_Doc.pdf (current two-page solution).\n2. Open 2_Outputs/RANKED_PROMOS.md for all 15 ranked promos, every ordered segment, hook, cliffhanger, why it works and posting priority. CSV and JSON contain the same recommendations.\n3. Read 2_Outputs/QUALITY_REVIEW.md for specific bad picks and limitations.\n4. Extract 3_Prototype_and_Code/source_code.zip; pip install -r requirements.txt; streamlit run app.py. Saved results need no API key. New AI extraction needs Gemini credentials and quota.\n5. Current artifact checks are in 6_Quality_Checking/submission_revision_verification.json. Original stress reports are historical.\n\nHuman evaluation and recordings are optional, not pending required deliverables. Optional historical review scaffolding is separated in 8_Optional_Historical. Original evidence remains preserved in outputs.zip.\n\nScores and cut boundaries are historical and unchanged. Source descriptions and posting rationales were corrected without new model scoring. Cached catalog results cover all 50 episodes; the fresh full-catalog attempt stopped at quota. No audience or conversion lift is claimed.\n\nPrivate packages contain Kuku-derived content; use only the designated review channel. Public source excludes outputs and credentials.\n',encoding='utf-8')
    with zipfile.ZipFile(submit/'4_Review_and_Walkthrough/all_cut_sheets.zip','w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(cuts.glob('*')):z.write(f,f.name)
    files=[f for f in root.rglob('*') if f.is_file() and '__pycache__' not in f.parts and '.pytest_cache' not in f.parts and f.name!='.env' and f.suffix not in {'.pyc'}]
    for name,include in [('outputs.zip',lambda f:f.is_relative_to(root/'outputs')),('source_code.zip',lambda f: not ('llm_cache' in f.parts)),('source_code_public.zip',lambda f:not f.is_relative_to(root/'outputs'))]:
        folder='2_Outputs' if name=='outputs.zip' else '3_Prototype_and_Code'
        with zipfile.ZipFile(submit/folder/name,'w',zipfile.ZIP_DEFLATED) as z:
            for f in files:
                if include(f):z.write(f,f.relative_to(root).as_posix())
    with zipfile.ZipFile(args.archive,'w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(submit.rglob('*')):
            if f.is_file():z.write(f,(Path(submit.name)/f.relative_to(submit)).as_posix())
    with zipfile.ZipFile(args.archive) as z: assert z.testzip() is None
    print('Rebuilt '+str(args.archive))
if __name__=='__main__':main()
