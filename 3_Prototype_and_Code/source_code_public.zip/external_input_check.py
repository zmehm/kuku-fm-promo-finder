"""One external-author input test, with fixed selection and no prompt tuning."""
from pathlib import Path
import hashlib,json,re,urllib.request
from datetime import datetime,timezone
from src.parser import parse_episode
from src.clips import fmt_ts
from src import config
from src.evidence import provenance
from quality_checks import register,registered,save

URL='https://www.gutenberg.org/cache/epub/1513/pg1513.txt'
OUT=config.OUTPUT_DIR/'external_validation'/'romeo_first_scene_v1'


def main():
    if (OUT/'protocol.json').exists(): raise ValueError('This external challenge is already frozen; preserve its first result.')
    OUT.mkdir(parents=True,exist_ok=True)
    # Commit selection and timing rules before fetching the source or observing outputs.
    protocol={'registered_at_utc':datetime.now(timezone.utc).isoformat(),'source_url':URL,'author':'William Shakespeare','work':'Romeo and Juliet','selection':'First complete scene in Act I; use its earliest contiguous prefix not exceeding 120 estimated seconds, ending at a complete speaker-turn or stage-direction boundary. Do not choose based on model output.','adaptation':'Preserve dialogue words and order; normalize whitespace; separate source stage directions; attach Unspecified emotion, never inferred emotion. Speech duration assumes 150 words/minute; stage directions assume 2 seconds. These are synthetic timing coordinates, not measured footage.','first_attempt_policy':'One registered uncached AI extraction; retain abstention, unavailable audits and failure. No retuning against the result and no switching excerpts to obtain a pass.','independence_scope':'Independent authorship and external to this project development corpus. Public classic may be present in model pretraining; not a novel privately supplied contemporary microdrama or authenticated independent evaluator input.','adapter_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'status':'protocol_frozen_before_source_fetch'}
    save(OUT/'protocol.json',protocol)
    request=urllib.request.Request(URL,headers={'User-Agent':'PromoFinderAssignment/1.0 (public-domain external-input validation)'})
    raw=urllib.request.urlopen(request,timeout=45).read()
    (OUT/'original_gutenberg_1513.txt').write_bytes(raw)
    text=raw.decode('utf-8-sig').replace('\r\n','\n')
    start=re.search(r'(?m)^ACT I\s*\n\s*SCENE I\.[^\n]*\n',text)
    if not start: raise ValueError('Expected source Act I / Scene I heading not found; do not silently select a different source.')
    tail=text[start.end():];end=re.search(r'(?m)^SCENE II\.',tail)
    if not end: raise ValueError('Expected scene boundary not found.')
    scene=tail[:end.start()]
    (OUT/'original_scene.txt').write_text(scene,encoding='utf-8')
    pieces=[];speaker=None
    for paragraph in re.split(r'\n\s*\n',scene):
        paragraph=paragraph.strip()
        if not paragraph: continue
        lines=paragraph.splitlines()
        if re.fullmatch(r"[A-Z][A-Z '?.-]*\.",lines[0].strip()):
            speaker=lines[0].strip()[:-1].replace('?',"'");body='\n'.join(lines[1:]).strip()
        else: body=paragraph
        if not body: continue
        for block in re.split(r'(\[_[\s\S]*?_\])',body):
            block=block.strip()
            if not block: continue
            if block.startswith('[_'):
                pieces.append(('ACTION',None,' '.join(block[2:-2].split())))
            else:
                # Bare Enter stage directions can share a paragraph with speech.
                for part in re.split(r'(?m)(^\s*Enter [^\n]+$)',block):
                    part=' '.join(part.split())
                    if not part: continue
                    if part.startswith('Enter ') or speaker is None: pieces.append(('ACTION',None,part))
                    else: pieces.append(('DIALOGUE',speaker,part))
    selected=[];clock=0.0
    for kind,name,content in pieces:
        seconds=2.0 if kind=='ACTION' else max(1.0,round(len(content.split())/2.5,2))
        if clock+seconds>120: break
        selected.append({'type':kind,'speaker':name,'content':content,'start':round(clock,2),'end':round(clock+seconds,2)})
        clock=round(clock+seconds,2)
    if clock<20: raise ValueError('Fixed excerpt is too short for the task; record failure instead of choosing a different excerpt.')
    script=OUT/'episode-950-external.txt'
    adapted=f'EPISODE NUMBER: Episode 950\nEPISODE LOGLINE: External play excerpt; no plot summary supplied.\nCONTINUITY NOTES: Estimated timing only; emotions unspecified; no footage.\n\nSCENE 01\nScene heading: EXT. PUBLIC PLACE - DAY\nScene start: 00:00.00\nScene end: {fmt_ts(clock)}\n\nActions and dialogue:\n\n'
    for item in selected:
        header='ACTION' if item['type']=='ACTION' else f"{item['speaker']} (Unspecified)"
        adapted+=f"**{header}:**\nStart: ({fmt_ts(item['start'])}) | End: ({fmt_ts(item['end'])})\n{item['content']}\n\n"
    script.write_text(adapted,encoding='utf-8')
    ep=parse_episode(script)
    save(OUT/'adaptation.json',{'source_sha256':hashlib.sha256(raw).hexdigest(),'source_scene_sha256':hashlib.sha256(scene.encode()).hexdigest(),'input_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'adapted_duration_sec':clock,'elements':selected,'parsed_elements':ep.total_elements,'emotion_annotations':'Unspecified only','warning':'Speech rate and stage durations are fixed assumptions; timestamp validity is internal to this adapter, not evidence of video-cut accuracy.'})
    record=register(script,OUT/'challenge.json','independent-author')
    before=record['proof']['fingerprint']
    result=registered(OUT/'challenge.json',OUT/'first_ai_attempt')
    final={'status':result['status'],'source_url':URL,'author':'William Shakespeare','selection_fixed_before_run':True,'prompt_tuned_after_result':False,'registered_fingerprint':before,'input_sha256':record['input_sha256'],'adapted_duration_sec':clock,'parsed_elements':ep.total_elements,'final_recommendations':len(result.get('ranked',[])),'pre_evidence_recommendations':len(result.get('pre_evidence_ranked',result.get('ranked',[]))),'evidence_checks':result.get('evidence_audits',[]),'main_api_usage':result.get('manifest',{}).get('live_api_usage'),'evidence_api_usage':result.get('evidence_api_usage'),'raw_result':'first_ai_attempt/result.json','limitation':protocol['independence_scope'],'timing_limitation':protocol['adaptation'],'interpretation':'First external-source execution result, not proof of independent human preference, model-training novelty, real footage timing, or unseen-show generalization.'}
    save(OUT/'summary.json',final)
    (OUT/'RESULT.md').write_text('# External-author first-input test\n\nSource: '+URL+'\n\nStatus: '+final['status']+'\n\nFinal recommendations: '+str(final['final_recommendations'])+'\n\n'+final['interpretation']+'\n\n'+final['limitation']+'\n\n'+final['timing_limitation'],encoding='utf-8')
    print(json.dumps({k:v for k,v in final.items() if k!='evidence_checks'},indent=2))

if __name__=='__main__': main()
