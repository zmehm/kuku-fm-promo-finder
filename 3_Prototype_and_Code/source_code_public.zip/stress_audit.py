"""Strict, reproducible offline stress audit. Does not modify submission evidence."""
from __future__ import annotations
import contextlib,csv,hashlib,io,json,logging,os,random,re,subprocess,sys,tempfile,time,zipfile
from collections import Counter
from datetime import datetime
from pathlib import Path
from src import config
from src.parser import parse_episode,parse_all_episodes,normalize_timestamp
from src.schemas import PromoCandidate,PromoSegment,RankedPromo,ParsedEpisode
from src.clips import fmt_ts,render_clip_text
from src.pipeline import run_pipeline
from src.llm_client import HeuristicClient,GeminiClient
from src.quality_checker import validate_timestamps,validate_duration,run_all_validations,total_duration
from review_tools import load_artifacts,cut_sheet,score
from test_revision import synthetic

logging.disable(logging.CRITICAL)
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs'/('stress_audit_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
OUT.mkdir(parents=True)
results=[]

def record(name,ok,detail,category='functional'):
    item={'name':name,'status':'PASS' if ok else 'FAIL','category':category,'detail':detail}
    results.append(item);print(f"[{item['status']}] {name}: {detail}",flush=True)

def command(name,args,cwd=ROOT,timeout=90):
    env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONIOENCODING']='utf-8'
    try:
        run=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout)
        (OUT/(name+'.log')).write_text(run.stdout+'\n'+run.stderr,encoding='utf-8')
        record(name,run.returncode==0,f'exit={run.returncode}; see {name}.log')
    except subprocess.TimeoutExpired:
        record(name,False,f'Timed out after {timeout}s')

def make_promo(ep,start=0,end=48):
    return PromoCandidate(promo_id='AUDIT',promo_type='single_episode',episodes=[ep.episode_number],segments=[PromoSegment(episode=ep.episode_number,start_time=fmt_ts(start),end_time=fmt_ts(end),start_seconds=start,end_seconds=end)],hook='A captain discovers an impossible radio signal',cliffhanger='The sealed cabin contains an unexplained presence',why_it_works='An understandable mystery leaves the immediate outcome unresolved.')

tracked=[ROOT/'outputs/revised/run_manifest.json',ROOT/'outputs/revised/ranked/ranked_promos.json',ROOT/'outputs/editor_review/results.json',ROOT.parent/'Kuku_FM_Combined_Submission_Zeeshan_Mehmood.zip']+list((ROOT/'outputs/editor_review').glob('reviewer_*/ratings.csv'))
digest=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
before={str(f):digest(f) for f in tracked}
command('regression_suite',[sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider','test_parser.py','test_revision.py','test_review_tools.py','test_hardening.py','test_human_review.py','test_quality_checks.py'])
eps,ranked=load_artifacts(ROOT/'outputs/revised')
with tempfile.TemporaryDirectory(prefix='promo_stress_') as td:
    temp=Path(td)
    base=synthetic()
    variants={
        'valid_original':(base,True,8),
        'valid_crlf':(base.replace('\n','\r\n'),True,8),
        'valid_bom':('\ufeff'+base,True,8),
        'valid_comma':(synthetic(decimal=','),True,8),
        'valid_one_decimal':(base.replace('.00','.0'),True,8),
        'valid_three_decimals':(base.replace('.00','.000'),True,8),
        'valid_aliases':(base.replace('(Mira)','(Zara)'),True,8),
        'empty':('',False,None),
        'prose':('A captain hears a signal. The end.',False,None),
        'header_only':('EPISODE NUMBER: Episode 901',False,None),
        'unsupported_header':(base.replace('**CAPTAIN (Mira) (Shocked):**','**Captain [Mira]:**'),False,None),
        'inverted_element':(base.replace('Start: (00:00.00) | End: (00:06.00)','Start: (00:08.00) | End: (00:06.00)',1),False,None),
        'zero_length_element':(base.replace('End: (00:06.00)','End: (00:00.00)',1),False,None),
        'seconds_out_of_range':(base.replace('End: (00:06.00)','End: (00:99.00)',1),False,None),
        'malformed_timed_block':(base.replace('Start: (00:00.00) | End: (00:06.00)','Start: (not-a-time) | End: (00:06.00)',1),False,None),
        'missing_timed_block':(base.replace('Start: (00:00.00) | End: (00:06.00)','',1),False,None),
        'duplicate_episode':(base+'\n'+base,False,None),
    }
    for name,(text,valid,count) in variants.items():
        path=temp/(name+'.txt');path.write_text(text,encoding='utf-8',newline='')
        try:
            ep=parse_episode(path)
            ok=valid and ep.total_elements==count
            invalid=sum(e.end_seconds<=e.start_seconds for e in ep.get_all_elements())
            record('parser_'+name,ok,f'accepted {ep.total_elements} elements; nonpositive intervals={invalid}; expected '+('complete parse' if valid else 'explicit rejection'),'parser')
        except Exception as exc:
            record('parser_'+name,not valid,f'{type(exc).__name__}: {str(exc)[:180]}','parser')
    ep_path=temp/'episode-901.txt';ep_path.write_text(base,encoding='utf-8');ep=parse_episode(ep_path)
    invalid_times=['00:60.00','00:99.00','99:99.99']
    for ts in invalid_times:
        try:
            normalized=normalize_timestamp(ts)
            record('invalid_timestamp_'+ts,False,f'Accepted as {normalized}; seconds must be 00-59','parser')
        except ValueError as exc: record('invalid_timestamp_'+ts,True,str(exc),'parser')
    # Random valid clock strings must preserve their own centisecond value.
    rng=random.Random(947)
    good=0
    for _ in range(1000):
        minute=rng.randrange(99);second=rng.randrange(60);fraction=rng.randrange(100)
        ts=f'{minute:02d}:{second:02d}.{fraction:02d}'
        good+=normalize_timestamp(ts)==ts
    record('timestamp_fuzz_1000',good==1000,f'{good}/1000 valid centisecond strings preserved','timing')
    checked=0;issues=[];dialogue=[]
    candidates=json.loads((ROOT/'outputs/revised/promos/promo_candidates.json').read_text(encoding='utf-8'))
    for label,rows in [('candidate',candidates),('ranked',[r.promo.model_dump() for r in ranked])]:
        for raw in rows:
            promo=PromoCandidate.model_validate(raw);checked+=1
            flags=validate_timestamps(promo,eps)+validate_duration(promo)
            inconsistent=[s for s in promo.segments if s.start_time!=fmt_ts(s.start_seconds) or s.end_time!=fmt_ts(s.end_seconds)]
            if flags or inconsistent: issues.append({'source':label,'id':promo.promo_id,'flags':[f.model_dump() for f in flags],'string_numeric_mismatch':bool(inconsistent)})
    ranked_issues=[x for x in issues if x['source']=='ranked']
    record('catalog_timestamp_integrity',not ranked_issues,f'{checked} candidate/ranked entries checked; candidate issues={len(issues)-len(ranked_issues)}, ranked issues={len(ranked_issues)}','timing')
    (OUT/'catalog_integrity.json').write_text(json.dumps(issues,indent=2),encoding='utf-8')
    for row in ranked:
        crossing=cut_sheet(row,eps)['dialogue_crossing_boundaries']
        if crossing: dialogue.append({'promo_id':row.promo.promo_id,'crossing':crossing})
    record('ranked_dialogue_boundary_crossings',not dialogue,f'{len(dialogue)}/{len(ranked)} shortlisted promos cross dialogue boundaries','timing')
    (OUT/'dialogue_crossings.json').write_text(json.dumps(dialogue,indent=2),encoding='utf-8')
    promo=make_promo(ep)
    corrupted=promo.model_copy(deep=True);corrupted.segments[0].start_time='00:12.00'
    record('validator_string_numeric_consistency',bool(validate_timestamps(corrupted,{901:ep})),'A numeric 0s start labelled 00:12.00 must be flagged','timing')
    duplicate=promo.model_copy(deep=True)
    seg=duplicate.segments[0];seg.end_seconds=24;seg.end_time='00:24.00';duplicate.segments=[seg,seg.model_copy(deep=True)];duplicate.total_duration_sec=48
    record('validator_repeated_internal_segment',bool(run_all_validations([duplicate],{901:ep})),'Same 0-24s segment repeated twice should be detected, not treated as a novel 48s promo','timing')
    missing=promo.model_copy(deep=True);missing.segments[0].episode=999
    record('validator_unknown_episode',bool(validate_timestamps(missing,{901:ep})),'Unknown episode 999 flagged','timing')
    long_ep=ep.model_copy(deep=True);long_ep.scenes[0].elements[0].content='A'*400+' ESSENTIAL_ENDING_REVEAL'
    visible='ESSENTIAL_ENDING_REVEAL' in render_clip_text(promo,{901:long_ep})
    record('long_dialogue_judge_visibility',visible,'A critical reveal after 400 characters '+('is visible' if visible else 'is truncated in the default scoring renderer'),'quality')
    # Explicit closure, and counterexamples, exercise actual ending behavior.
    from src.quality_checker import validate_resolution_cues
    closed=ep.model_copy(deep=True);closed.scenes[0].elements[-2].content="It is over. We are safe now."
    closed.scenes[0].elements[-2].end_seconds=48;closed.scenes[0].elements[-2].end_time="00:48.00"
    record('explicit_closure_review_hint',bool(validate_resolution_cues(promo,{901:closed})),'Explicit ending closure is flagged for editor review, not certified semantically resolved','quality')
    closed.scenes[0].elements[-2].content="We are safe now. But look behind you!"
    record('new_threat_not_false_closure',not validate_resolution_cues(promo,{901:closed}),'A new threat after apparent closure is not flagged as resolved','quality')
    # Full catalog offline load/concurrency; compare source cuts and scores.
    timings={};signatures=[]
    for workers in [1,4]:
        start=time.perf_counter();r=run_pipeline(eps,client=HeuristicClient(),run_baselines=False,workers=workers)
        elapsed=time.perf_counter()-start;timings[str(workers)]=round(elapsed,3)
        signatures.append([(x.promo.model_dump(),x.scores.model_dump()) for x in r.ranked])
        record(f'offline_catalog_workers_{workers}',bool(r.ranked) and all(not validate_timestamps(x.promo,eps) and 20<=total_duration(x.promo)<=60 for x in r.ranked),f'50 episodes; {len(r.candidates)} candidates; {len(r.ranked)} shortlisted; {elapsed:.3f}s','load')
    record('offline_concurrency_stability',signatures[0]==signatures[1],f'1 vs 4 workers; timings={timings}','load')
    sig=[]
    for _ in range(20):
        r=run_pipeline({901:ep},client=HeuristicClient(),run_baselines=False)
        sig.append([(x.promo.model_dump(),x.scores.model_dump()) for x in r.ranked])
    record('offline_repeat_stability_20',all(x==sig[0] for x in sig),'20 repeated offline runs compared','load')
    unavailable=GeminiClient(use_cache=False);unavailable._client=None
    r=run_pipeline({901:ep},client=unavailable,run_baselines=False)
    disclosed=all(r.manifest['fallback_to_heuristic'][k] for k in ['moments','construction','scoring'])
    record('unavailable_api_fallback',bool(r.ranked) and disclosed,f"Shortlisted {len(r.ranked)}; fallbacks={r.manifest['fallback_to_heuristic']}; critique failures={r.manifest['critique_failures']}",'resilience')
    # Legacy audit as supplementary evidence, not a strict validation oracle:
    # its parser test accepts any descriptive exception as PASS even on valid inputs.
    import stress_test as legacy
    legacy.OUT=OUT/'legacy';legacy.RESULTS=legacy.OUT/'stress_results.json'
    previous={k:getattr(config,k) for k in ['PARSED_DIR','PROMOS_DIR','RANKED_DIR']}
    config.PARSED_DIR=ROOT/'outputs/revised/parsed';config.PROMOS_DIR=ROOT/'outputs/revised/promos';config.RANKED_DIR=ROOT/'outputs/revised/ranked'
    capture=io.StringIO()
    with contextlib.redirect_stdout(capture): legacy.t_parser();legacy.t_integrity();legacy.t_adversarial()
    for key,value in previous.items(): setattr(config,key,value)
    (OUT/'legacy_checks.log').write_text(capture.getvalue(),encoding='utf-8')
    old=json.loads(legacy.RESULTS.read_text(encoding='utf-8'))
    record('rule_adversarial_detection',old['adversarial']['caught']==old['adversarial']['expected'],f"Caught {old['adversarial']['caught']}/{old['adversarial']['expected']} known bad cases; details in legacy_checks.log",'quality')
    # Reconstruct each actual blind handout from the private key; require exact
    # source text and no visible source/rank labels in the static HTML.
    from html import unescape
    review=ROOT/'outputs/editor_review';keys=json.loads((review/'private/keys.json').read_text(encoding='utf-8'))
    all_pair_text=True;counts=[]
    for reviewer,key in keys.items():
        page=unescape((review/reviewer/'review.html').read_text(encoding='utf-8'))
        counts.append(len(key))
        for item in key.values():
            matching=[x for x in ranked if x.promo.promo_id==item['promo_id']]
            all_pair_text&=bool(matching) and render_clip_text(matching[0].promo,eps,max_chars=100000) in page
        all_pair_text&='pipeline_side' not in page and 'original_composite' not in page
    record('blind_review_content_integrity',all_pair_text and counts==[10,10,10],f'Exact pipeline source text verified in 3 handouts; pair counts={counts}','evaluation')
    # Validate ZIP integrity and run freshly extracted code, not the workspace copy.
    submission=ROOT.parent/'Kuku_FM_Submission_Zeeshan_Mehmood'
    for label,name in [('private','source_code.zip'),('public','source_code_public.zip')]:
        archive=submission/'3_Prototype_and_Code'/name
        directory=temp/label;directory.mkdir()
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            for member in z.infolist():
                dest=(directory/member.filename).resolve();assert directory.resolve() in dest.parents
            z.extractall(directory)
        with zipfile.ZipFile(archive) as z:
            parity=all(z.read(name)==(ROOT/name).read_bytes() for name in ['src/parser.py','src/quality_checker.py','src/clips.py','src/llm_client.py','src/evidence.py','quality_checks.py','test_hardening.py','test_quality_checks.py'])
        record('packaged_'+label+'_hardening_parity',parity,'Archived hardening code and tests exactly match the verified workspace','packaging')
        command('packaged_'+label+'_regressions',[sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider','test_parser.py','test_revision.py','test_review_tools.py','test_hardening.py','test_human_review.py','test_quality_checks.py'],directory,60)
        snippet="from streamlit.testing.v1 import AppTest; a=AppTest.from_file('app.py').run(timeout=30); assert not a.exception, list(a.exception); print('packaged app loaded')"
        command('packaged_'+label+'_dashboard',[sys.executable,'-B','-c',snippet],directory,60)
        command('packaged_'+label+'_offline',[sys.executable,'-B','review_tools.py','unseen','--script','synthetic_inheritance_example.txt','--out',str(temp/(label+'_run')),'--mode','offline'],directory,60)
    combined=ROOT.parent/'Kuku_FM_Combined_Submission_Zeeshan_Mehmood.zip'
    with zipfile.ZipFile(combined) as z: record('combined_zip_integrity',z.testzip() is None,f'{len(z.namelist())} outer entries checked','packaging')
record('submission_evidence_unchanged',all(digest(Path(f))==value for f,value in before.items()),'SHA-256 comparison of manifests, ranked output, reviewer ratings/results and combined ZIP','integrity')
summary={'scope':'Offline stress tests and isolated packaged-app executions. No fresh API calls; unavailable API was simulated. No human quality or ad-conversion validation.','counts':dict(Counter(x['status'] for x in results)),'checks':results}
(OUT/'report.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
text='# Stress audit\n\n'+summary['scope']+'\n\n'+f"Passed: {summary['counts'].get('PASS',0)}. Failed: {summary['counts'].get('FAIL',0)}.\n\n"+'\n'.join(f"- **{x['status']} {x['name']}**: {x['detail']}" for x in results)
(OUT/'REPORT.md').write_text(text,encoding='utf-8')
print('REPORT',OUT/'REPORT.md',flush=True)
print('COUNTS',summary['counts'],flush=True)
