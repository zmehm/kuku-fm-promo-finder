"""Editor cut sheets, matched blind review, and honest fresh-input validation.
Run: python review_tools.py prepare | score | unseen --script new.txt
"""
from __future__ import annotations
import argparse
import io
import hashlib
from datetime import datetime, timezone
import csv
import html
import json
import logging
import random
from collections import Counter
from pathlib import Path
from src import config
from src.clips import render_clip_text, element_text
from src.schemas import ParsedEpisode, PromoCandidate, RankedPromo, ElementType
from src.quality_checker import generate_last30_baseline, validate_timestamps, total_duration

CHOICES={"A","B","Tie","Neither"}
FIELDS=["pair_id","hook_pick","cliffhanger_pick","coherence_pick","overall_pick","reason"]


def load_artifacts(base):
    episodes={}
    for f in sorted((base/"parsed").glob("episode-*.json")):
        ep=ParsedEpisode.model_validate_json(f.read_text(encoding="utf-8"))
        episodes[ep.episode_number]=ep
    rows=[RankedPromo.model_validate(x) for x in json.loads((base/"ranked/ranked_promos.json").read_text(encoding="utf-8"))]
    return episodes,rows


def cut_sheet(row,episodes):
    promo=row.promo
    total=total_duration(promo)
    first=[]; last=[]; crossing=[]; segments=[]; offset=0.0
    for number,seg in enumerate(promo.segments,1):
        ep=episodes[seg.episode]
        for e in ep.get_all_elements():
            if e.element_type==ElementType.DIALOGUE:
                for label,boundary in [("start",seg.start_seconds),("end",seg.end_seconds)]:
                    if e.start_seconds+0.011 < boundary < e.end_seconds-0.011:
                        crossing.append({"segment":number,"boundary":label,"speaker":e.character,"text":e.content,"start":e.start_time,"end":e.end_time})
            start=max(e.start_seconds,seg.start_seconds)
            end=min(e.end_seconds,seg.end_seconds)
            if end<=start: continue
            relative=round(offset+start-seg.start_seconds,6)
            relative_end=round(offset+end-seg.start_seconds,6)
            item={"offset_start":round(relative,2),"offset_end":round(relative_end,2),"text":element_text(e),"source_start":e.start_time,"source_end":e.end_time}
            if relative<3 and relative_end>0: first.append(item)
            if relative_end>total-5 and relative<total: last.append(item)
        segments.append({"order":number,**seg.model_dump(),"duration":round(seg.duration_sec(),2)})
        offset+=seg.duration_sec()
    return {"promo_id":promo.promo_id,"rank":row.rank,"score":row.scores.composite,"duration":round(total,2),"segments":segments,"hook_claim":promo.hook,"cliffhanger_claim":promo.cliffhanger,"posting_rationale":row.posting_rationale,"why_it_works":promo.why_it_works,"first_3_seconds":first,"last_5_seconds":last,"dialogue_crossing_boundaries":crossing,"source_text":render_clip_text(promo,episodes,max_chars=100000),"review_status":"Source evidence prepared for review. Script evidence is not footage validation."}


def sheet_markdown(sheet):
    def evidence(items):
        return "\n".join(f"- +{e['offset_start']:.2f}s to +{e['offset_end']:.2f}s: {e['text']}" for e in items) or "- No timed content overlaps this window."
    segments="\n".join(f"{s['order']}. Episode {s['episode']}: {s['start_time']} - {s['end_time']} ({s['duration']:.2f}s)" for s in sheet['segments'])
    warnings="\n".join(f"- Segment {x['segment']} {x['boundary']} crosses {x['speaker']} dialogue ({x['start']}-{x['end']}): {x['text']}" for x in sheet['dialogue_crossing_boundaries']) or "No dialogue crosses a selected boundary in parsed script data."
    return f"# {sheet['promo_id']} - rank {sheet['rank']}\n\nDuration: {sheet['duration']:.2f}s. Model score: {sheet['score']:.2f}/10.\n\n## Ordered cut list\n\n{segments}\n\n## Opening evidence: first three seconds\n\n{evidence(sheet['first_3_seconds'])}\n\nClaim to verify: {sheet['hook_claim']}\n\n## Ending evidence: last five seconds\n\n{evidence(sheet['last_5_seconds'])}\n\nClaim to verify: {sheet['cliffhanger_claim']}\n\n## Boundary review\n\n{warnings}\n\n## Posting rationale\n\n{sheet['posting_rationale']}\n\n{sheet['why_it_works']}\n\nQuality check: inspect opening timing, the specific unresolved outcome, and cold-viewer context; see QUALITY_REVIEW.md for known weaknesses.\n\n## Verbatim source text\n\n```text\n{sheet['source_text']}\n```\n"


def prepare(base,out,seed=2026,n=10):
    eps,rows=load_artifacts(base)
    if (out/"protocol.json").exists(): raise ValueError("Review pack already exists; use a new --out folder to preserve ratings and assignment.")
    out.mkdir(parents=True,exist_ok=True)
    cuts=out/"cut_sheets"; cuts.mkdir()
    all_sheets=[cut_sheet(row,eps) for row in rows]
    for sheet in all_sheets:
        (cuts/(sheet['promo_id']+'.md')).write_text(sheet_markdown(sheet),encoding="utf-8")
    (cuts/"cut_sheets.json").write_text(json.dumps(all_sheets,indent=2),encoding="utf-8")
    (out/"five_clip_review.md").write_text("# Five-clip review evidence - human conclusions pending\n\n"+"\n\n---\n\n".join(sheet_markdown(x) for x in all_sheets[:5]),encoding="utf-8")
    with (out/"manual_review.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f);w.writerow(["promo_id","hook_within_3s_yes_no","unresolved_ending_yes_no","cold_viewer_understands_yes_no","dialogue_preserved_yes_no","decision_keep_trim_reject","reason"])
        for row in rows[:5]: w.writerow([row.promo.promo_id,"","","","","",""])
    # Match comparisons by episode. Sampling is among recommended episodes,
    # explicitly a conditional comparison, not representative of the full catalog.
    best={}
    for row in rows:
        if len(row.promo.episodes)==1:
            ep=row.promo.episodes[0]
            if ep not in best or row.scores.composite>best[ep].scores.composite: best[ep]=row
    baseline={b.episodes[0]:b for b in generate_last30_baseline(eps,n=len(eps))}
    eligible=sorted(set(best)&set(baseline))
    selected=random.Random(seed).sample(eligible,min(n,len(eligible)))
    if len(selected)<n: raise ValueError(f"Only {len(selected)} eligible matched episodes; requested {n}.")
    private=out/"private";private.mkdir()
    keys={};order={}
    for rater in ["reviewer_1","reviewer_2","reviewer_3"]:
        directory=out/rater;directory.mkdir()
        rng=random.Random(f"{seed}-{rater}")
        episode_order=selected.copy();rng.shuffle(episode_order)
        key={}; cards=[]
        with (directory/"ratings.csv").open("w",newline="",encoding="utf-8") as f:
            w=csv.DictWriter(f,fieldnames=["reviewer_id",*FIELDS]);w.writeheader()
            for i,ep in enumerate(episode_order,1):
                pair=f"P{i:02d}"
                pipeline_a=rng.choice([True,False])
                a,b=(best[ep].promo,baseline[ep]) if pipeline_a else (baseline[ep],best[ep].promo)
                key[pair]={"episode":ep,"pipeline_side":"A" if pipeline_a else "B","promo_id":best[ep].promo.promo_id}
                w.writerow({"reviewer_id":rater,"pair_id":pair})
                cards.append(f"<section><h2>{pair}</h2><div class='pair'><article><h3>A</h3><pre>{html.escape(render_clip_text(a,eps,max_chars=100000))}</pre></article><article><h3>B</h3><pre>{html.escape(render_clip_text(b,eps,max_chars=100000))}</pre></article></div></section>")
        page="<!doctype html><meta charset='utf-8'><title>Blind clip review</title><style>body{font:16px system-ui;margin:28px;max-width:1400px}.pair{display:grid;grid-template-columns:1fr 1fr;gap:20px}pre{white-space:pre-wrap;background:#f4f4f4;padding:16px}section{border-top:1px solid #bbb;margin-top:30px}@media(max-width:700px){.pair{grid-template-columns:1fr}}</style><h1>Blind clip review</h1><p>Read each clip as a new viewer. In ratings.csv choose A, B, Tie, or Neither for the first-three-second hook, unresolved ending, standalone clarity, and overall preference. An overall choice and short reason are requested; dimension choices are encouraged. Neither means neither is worth posting. Do not seek the source labels or discuss choices until everyone finishes. Judge the clips themselves, not word count. This is script-only review, not a video or conversion test.</p>"+"".join(cards)
        (directory/"review.html").write_text(page,encoding="utf-8")
        keys[rater]=key;order[rater]=episode_order
    (private/"keys.json").write_text(json.dumps(keys,indent=2),encoding="utf-8")
    protocol={"seed":seed,"n_pairs_per_rater":n,"n_raters":3,"selected_episodes":selected,"eligible_episodes":eligible,"sampling_scope":"Seeded sample of episodes with current single-episode shortlist recommendations and a duration-valid last-30s baseline. Not a random sample of all 50 episodes; conclusions apply to recommended episodes only.","comparison":"Highest-scoring current shortlisted promo for each sampled episode vs its own final approximately 30 seconds, snapped to source boundaries. Candidates can have different durations; preference evaluates the complete deliverable.","blinding":"Source, rank, score and hook/cliffhanger claims hidden. Side assignment and pair order randomized separately for each reviewer. Text content can still reveal a baseline ending.","analysis":"Descriptive vote totals and episode-majority counts. Ratings from different people on one episode are not independent episode samples. No significance or conversion claim.","human_ratings_status":"pending","manual_five_clip_status":"pending"}
    (out/"protocol.json").write_text(json.dumps(protocol,indent=2),encoding="utf-8")
    report=json.loads((base/"quality_report/quality_report.json").read_text(encoding="utf-8"))
    manifest=json.loads((base/"run_manifest.json").read_text(encoding="utf-8"))
    rejected=set(sum(manifest.get("dropped_in_selection",{}).values(),[]))
    example=next((x for x in report["flags"] if x["promo_id"] in rejected and x["severity"]=="high"),None)
    (out/"rejected_example.json").write_text(json.dumps({"status":"Automated rejection evidence; not a fabricated human decision","finding":example},indent=2),encoding="utf-8")
    return score(out)


def validate_rating_csv(content, key, reviewer=None, require_assignment=False):
    """Validate an assigned review sheet completely before accepting any writes."""
    reader=csv.DictReader(io.StringIO(content.decode('utf-8-sig')))
    if not reader.fieldnames or not {'pair_id','overall_pick'}.issubset(reader.fieldnames):
        raise ValueError("Ratings CSV must contain pair_id and overall_pick columns.")
    if require_assignment and "reviewer_id" not in reader.fieldnames:
        raise ValueError("Use the assigned handout CSV with its reviewer_id column intact.")
    rows=list(reader);seen=set()
    for row in rows:
        if reviewer and 'reviewer_id' in row and (row.get('reviewer_id') or '').strip()!=reviewer:
            raise ValueError('This sheet belongs to a different reviewer; choose its assigned reviewer.')
        pair=(row.get('pair_id') or '').strip()
        if pair in seen or pair not in key:
            raise ValueError(f"Duplicate or unknown pair {pair!r}")
        seen.add(pair);row['pair_id']=pair
        for field in FIELDS[1:5]:
            value=(row.get(field) or '').strip()
            if value and value not in CHOICES:
                raise ValueError(f"Invalid {field} choice {value!r} at {pair}")
            row[field]=value
    if seen != set(key):
        raise ValueError("Missing assigned pair IDs; keep every original row, leaving undecided choices blank.")
    return rows


def import_ratings(out,reviewer,content):
    """Import actual returned ratings; preserve prior file and log provenance."""
    keys=json.loads((out/'private/keys.json').read_text(encoding='utf-8'))
    if reviewer not in keys:
        raise ValueError("Choose a reviewer assigned to this evaluation.")
    validate_rating_csv(content,keys[reviewer],reviewer,require_assignment=True)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    target=out/reviewer/'ratings.csv'
    backup=out/'private'/'rating_backups';backup.mkdir(exist_ok=True)
    if target.exists(): (backup/f'{reviewer}_{stamp}.csv').write_bytes(target.read_bytes())
    target.write_bytes(content)
    log=out/'private'/'rating_imports.json'
    entries=json.loads(log.read_text(encoding='utf-8')) if log.exists() else []
    entries.append({'reviewer':reviewer,'imported_at_utc':stamp,'sha256':hashlib.sha256(content).hexdigest(),'origin':'Returned review sheet imported by operator; human authorship is not independently authenticated.'})
    log.write_text(json.dumps(entries,indent=2),encoding='utf-8')
    return score(out)


def human_review_summary(out):
    if not (out/'private/keys.json').exists():
        return 'Human review is not prepared. No new human preference results are available.'
    result=score(out,write=False)
    votes=result['dimension_votes']['overall_pick']
    totals=', '.join(f"{name}: {votes.get(name,0)}" for name in ['pipeline','baseline','tie','neither'])
    majority=', '.join(f"{k}: {v}" for k,v in result['episode_majority'].items()) or 'none yet'
    return (f"Human review status: {result['status']}. Completed {result['completed_ratings']}/{result['expected_ratings']} assigned ratings. "
        f"Overall votes - {totals}. Fully rated episodes: {result['fully_rated_episodes']}; episode majorities - {majority}. "
        'Small descriptive study conditional on recommended episodes; ratings on one episode are clustered. No ad-conversion inference.')


def score(out,write=True):
    keys=json.loads((out/"private/keys.json").read_text(encoding="utf-8"))
    episode_votes={};by_reviewer={};dimensions={f:Counter() for f in FIELDS[1:5]}
    for reviewer,key in keys.items():
        seen=set();counts=Counter();completed=0
        rows=validate_rating_csv((out/reviewer/'ratings.csv').read_bytes(),key,reviewer)
        for row in rows:
                pair=row['pair_id']
                if not row.get('overall_pick','').strip(): continue
                for field in FIELDS[1:5]:
                    value=row.get(field,'').strip()
                    if not value: continue
                    if value not in CHOICES: raise ValueError(f"Invalid {field} choice {value!r} at {reviewer}/{pair}")
                    outcome='pipeline' if value==key[pair]['pipeline_side'] else 'baseline' if value in {'A','B'} else value.lower()
                    dimensions[field][outcome]+=1
                    if field=='overall_pick':
                        counts[outcome]+=1;completed+=1
                        episode_votes.setdefault(key[pair]['episode'],[]).append(outcome)
        by_reviewer[reviewer]={"completed":completed,"expected":len(key),"votes":dict(counts)}
    majority=Counter();full=0
    for votes in episode_votes.values():
        if len(votes)!=len(keys): continue
        full+=1;counts=Counter(votes);top=counts.most_common()
        majority[top[0][0] if top[0][1]>len(keys)/2 else 'no_majority']+=1
    total=sum(x['completed'] for x in by_reviewer.values())
    expected=sum(len(x) for x in keys.values())
    result={"status":"complete" if total==expected else 'pending' if total==0 else 'partial',"completed_ratings":total,"expected_ratings":expected,"by_reviewer":by_reviewer,"dimension_votes":{k:dict(v) for k,v in dimensions.items()},"fully_rated_episodes":full,"episode_majority":dict(majority),"caveat":"Descriptive, small-sample, conditional on recommended episodes. Multiple ratings on an episode are clustered. No test of ad conversion; pending ratings are never treated as losses or wins."}
    if write:
        (out/"results.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
        protocol_path=out/"protocol.json"
        if protocol_path.exists():
            protocol=json.loads(protocol_path.read_text(encoding="utf-8"))
            protocol["human_ratings_status"]=result["status"]
            protocol_path.write_text(json.dumps(protocol,indent=2),encoding="utf-8")
    return result


def unseen(script,out,mode):
    from src.parser import parse_episode
    from src.llm_client import GeminiClient, HeuristicClient
    from src.pipeline import run_pipeline
    out.mkdir(parents=True,exist_ok=True)
    if (out/"result.json").exists(): raise ValueError("Use a new output folder to preserve earlier evidence.")
    ep=parse_episode(script)
    if mode=='ai':
        config.GEMINI_MAX_RETRIES=1
        client=GeminiClient(use_cache=False)
        if not client.available: raise ValueError("No configured Gemini API client; choose offline mode explicitly or configure GEMINI_API_KEY.")
        # A single fresh discovery request is the preflight; do not loop through
        # fallback stages and incorrectly report an unavailable API as success.
        try:
            preflight_moments=client.identify_moments(ep)
            client.identify_moments=lambda episode: preflight_moments
        except Exception as exc:
            message=str(exc)
            quota=any(x in message for x in ['429','RESOURCE_EXHAUSTED'])
            failure={"status":"blocked_by_quota" if quota else 'failed',"mode":"ai","cached":False,"error_kind":"API quota unavailable" if quota else type(exc).__name__,"limitation":"No fresh end-to-end AI success established. No model fallback substituted for this result."}
            (out/"result.json").write_text(json.dumps(failure,indent=2),encoding="utf-8")
            return failure
    else: client=HeuristicClient()
    result=run_pipeline({ep.episode_number:ep},client=client,run_baselines=False)
    for row in result.ranked:
        assert 20<=total_duration(row.promo)<=60
        assert not validate_timestamps(row.promo,{ep.episode_number:ep})
    mixed=any(result.manifest['fallback_to_heuristic'].values()) or bool(result.manifest.get('critique_failures')) or bool(result.manifest.get('trim_reaudit_failures'))
    status='ai_with_fallbacks' if mode=='ai' and mixed else 'ai_completed' if mode=='ai' else 'offline_completed'
    if not result.ranked: status='no_valid_shortlist'
    data={"status":status,"mode":mode,"cached":False,"input_origin":"User-supplied; independence from development data must be established by the reviewer, not inferred from a new filename.","manifest":result.manifest,"ranked":[r.model_dump() for r in result.ranked],"audit_flags":[f.model_dump() for f in result.flags],"candidate_promos":[c.model_dump() for c in result.candidates],"quality_report":result.report.model_dump(),"limitation":"Execution and boundaries checked; human marketing-quality assessment pending."}
    (out/"result.json").write_text(json.dumps(data,indent=2),encoding="utf-8")
    return data


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    prep=sub.add_parser('prepare');prep.add_argument('--base',type=Path,default=config.OUTPUT_DIR/'revised');prep.add_argument('--out',type=Path,default=config.OUTPUT_DIR/'editor_review');prep.add_argument('--seed',type=int,default=2026)
    rate=sub.add_parser('score');rate.add_argument('--out',type=Path,default=config.OUTPUT_DIR/'editor_review')
    incoming=sub.add_parser('import-ratings');incoming.add_argument('--out',type=Path,default=config.OUTPUT_DIR/'editor_review');incoming.add_argument('--reviewer',required=True);incoming.add_argument('--file',type=Path,required=True)
    fresh=sub.add_parser('unseen');fresh.add_argument('--script',type=Path,required=True);fresh.add_argument('--out',type=Path,required=True);fresh.add_argument('--mode',choices=['ai','offline'],default='offline')
    args=parser.parse_args()
    if args.command=='prepare': result=prepare(args.base,args.out,args.seed)
    elif args.command=='score': result=score(args.out)
    elif args.command=='import-ratings': result=import_ratings(args.out,args.reviewer,args.file.read_bytes())
    else: result=unseen(args.script,args.out,args.mode)
    print(json.dumps({k:v for k,v in result.items() if k not in {'ranked','manifest'}},indent=2))

if __name__=='__main__': main()
