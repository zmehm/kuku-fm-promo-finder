from pathlib import Path
import pytest
from src.parser import parse_episode
from src.pipeline import run_pipeline
from src.llm_client import HeuristicClient
from src.quality_checker import _AD_HARD_RE, validate_timestamps, total_duration


def synthetic(number=901, decimal="."):
    blocks = []
    lines = [
        ("**CAPTAIN (Mira) (Shocked):**", '"The rescue signal is coming from inside our ship!"'),
        ("**ENGINEER (V.O.) (Urgent):**", '"That cabin has been sealed for twenty years."'),
        ("**ACTION:**", "Mira breaks the seal; the lock shatters and the lights fail."),
        ("**CAPTAIN (Mira) (Defiant):**", '\"Open the hatch. Someone is still alive in there.\"'),
        ("**ENGINEER (O.S.) (Terrified):**", '\"Captain, the voice on the radio is yours.\"'),
        ("**ACTION:**", "A figure reaches for the hatch from the other side."),
        ("**CAPTAIN (Mira) (Shocked):**", '\"Then who is standing beside me?\"'),
        ("**SOUND FX:**", "Three knocks echo from the sealed cabin."),
    ]
    for i, (header, content) in enumerate(lines):
        start=f"00:{i*6:02d}.00".replace(".",decimal)
        end=f"00:{(i+1)*6:02d}.00".replace(".",decimal)
        blocks.append(f"{header}\nStart: ({start}) | End: ({end})\n{content}")
    return f"EPISODE NUMBER: Episode {number}\nEPISODE LOGLINE: A captain discovers an impossible rescue signal.\n\nSCENE 01\nScene heading: INT. STARSHIP - NIGHT\nScene start: 00:00.00\nScene end: 00:48.00\n\nActions and dialogue:\n\n"+"\n\n".join(blocks)


@pytest.mark.parametrize("decimal", [".", ","])
def test_unseen_synthetic_offline(tmp_path, decimal):
    path=tmp_path/"new_story.txt"
    path.write_text(synthetic(decimal=decimal),encoding="utf-8")
    ep=parse_episode(path)
    assert ep.episode_number==901
    assert ep.total_elements==8
    assert ep.total_dialogue_lines==5
    assert ep.get_dialogue_elements()[0].character=="CAPTAIN (Mira)"
    assert "(V.O.)" in ep.get_dialogue_elements()[1].character
    result=run_pipeline({901:ep},client=HeuristicClient(),run_baselines=False)
    assert result.ranked
    for row in result.ranked:
        assert 20<=total_duration(row.promo)<=60
        assert not validate_timestamps(row.promo,{901:ep})


@pytest.mark.parametrize("word", ["torture", "tortured", "torturing", "tortures"])
def test_risk_variants(word):
    assert _AD_HARD_RE.search(word)
    assert not _AD_HARD_RE.search("untorturedly")


def test_unsupported_input_is_rejected(tmp_path):
    path=tmp_path/"prose.txt"
    path.write_text("A captain hears a voice. The end.",encoding="utf-8")
    with pytest.raises(ValueError,match="No script elements"):
        parse_episode(path)


def test_trimmed_clip_is_rescored(tmp_path):
    from src.clips import id_to_segment
    from src.schemas import PromoCandidate, PromoScores
    path=tmp_path/"new.txt"
    path.write_text(synthetic().replace("The rescue signal is coming from inside our ship!", "They tortured our pilot!"),encoding="utf-8")
    ep=parse_episode(path)
    class RecordingClient(HeuristicClient):
        def __init__(self):
            super().__init__()
            self.starts=[]
        def construct_episode_promos(self, episode, moments, n):
            return [PromoCandidate(promo_id="TEST",promo_type="single_episode",episodes=[901],segments=[id_to_segment(episode,"901.001","901.008")],hook="A captain investigates a mysterious signal",cliffhanger="An impossible voice leaves the crew in danger",why_it_works="A mysterious rescue signal creates a clear unresolved conflict.")]
        def score_promo(self, promo, episodes):
            start=promo.segments[0].start_seconds
            self.starts.append(start)
            value=9 if start==0 else 4
            return PromoScores(hook_strength=value,cliffhanger_quality=value,standalone_coherence=value,emotional_impact=value,duration_fitness=value),f"Score for start {start}"
    client=RecordingClient()
    result=run_pipeline({901:ep},client=client,run_baselines=False)
    assert client.starts==[0,6]
    assert result.ranked
    assert result.ranked[0].scores.composite==4
    assert result.ranked[0].promo.total_duration_sec==42
    assert result.ranked[0].score_reasoning=="Score for start 6.0"


def test_partial_unsupported_format_fails_loudly(tmp_path):
    path=tmp_path/"partial.txt"
    path.write_text(synthetic().replace("**CAPTAIN (Mira) (Shocked):**", "**Captain [Mira]:**"),encoding="utf-8")
    with pytest.raises(ValueError,match="Unsupported timed element"):
        parse_episode(path)
