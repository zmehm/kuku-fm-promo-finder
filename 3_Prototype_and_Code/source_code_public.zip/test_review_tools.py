import csv
import json
from pathlib import Path
import pytest
from review_tools import score, cut_sheet, unseen
from test_revision import synthetic
from src.parser import parse_episode
from src.pipeline import run_pipeline
from src.llm_client import HeuristicClient


def pack(tmp_path, choices):
    private=tmp_path/'private';private.mkdir()
    keys={}
    for i,(side,pick) in enumerate(choices,1):
        name=f'reviewer_{i}';directory=tmp_path/name;directory.mkdir()
        keys[name]={'P01':{'pipeline_side':side,'episode':42}}
        with (directory/'ratings.csv').open('w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f,fieldnames=['pair_id','overall_pick','hook_pick']);w.writeheader();w.writerow({'pair_id':'P01','overall_pick':pick})
    (private/'keys.json').write_text(json.dumps(keys),encoding='utf-8')


def test_unrated_pack_is_pending(tmp_path):
    pack(tmp_path,[('A',''),('B',''),('A','')])
    result=score(tmp_path)
    assert result['status']=='pending'
    assert result['completed_ratings']==0
    assert result['episode_majority']=={}


def test_votes_resolve_independently_randomized_sides(tmp_path):
    pack(tmp_path,[('A','A'),('B','B'),('B','A')])
    result=score(tmp_path)
    assert result['status']=='complete'
    assert result['dimension_votes']['overall_pick']=={'pipeline':2,'baseline':1}
    assert result['fully_rated_episodes']==1
    assert result['episode_majority']=={'pipeline':1}


def test_ties_neither_and_partial(tmp_path):
    pack(tmp_path,[('A','Tie'),('B','Neither'),('A','')])
    result=score(tmp_path)
    assert result['status']=='partial'
    assert result['dimension_votes']['overall_pick']=={'tie':1,'neither':1}
    assert result['fully_rated_episodes']==0


def test_invalid_vote_rejected(tmp_path):
    pack(tmp_path,[('A','Pipeline')])
    with pytest.raises(ValueError,match='Invalid'): score(tmp_path)


def test_duplicate_pair_rejected(tmp_path):
    pack(tmp_path,[('A','A')])
    with (tmp_path/'reviewer_1/ratings.csv').open('a',encoding='utf-8') as f: f.write('P01,B,\n')
    with pytest.raises(ValueError,match='Duplicate'): score(tmp_path)


def test_cut_sheet_detects_overlapping_dialogue(tmp_path):
    path=tmp_path/'new.txt';path.write_text(synthetic(),encoding='utf-8')
    ep=parse_episode(path)
    row=run_pipeline({901:ep},client=HeuristicClient(),run_baselines=False).ranked[0]
    row.promo.segments[0].start_seconds=3
    row.promo.segments[0].start_time='00:03.00'
    sheet=cut_sheet(row,{901:ep})
    assert sheet['dialogue_crossing_boundaries']
    assert sheet['first_3_seconds'][0]['offset_start']==0
    assert 'review' in sheet['review_status'].lower() or 'pending' in sheet['review_status'].lower()


def test_quota_failure_never_claims_ai_success(tmp_path,monkeypatch):
    import src.llm_client as clients
    class Unavailable:
        available=True
        def __init__(self,**kwargs): pass
        def identify_moments(self,ep): raise RuntimeError('429 RESOURCE_EXHAUSTED private diagnostic')
    monkeypatch.setattr(clients,'GeminiClient',Unavailable)
    path=tmp_path/'new.txt';path.write_text(synthetic(),encoding='utf-8')
    result=unseen(path,tmp_path/'audit','ai')
    assert result['status']=='blocked_by_quota'
    assert 'ranked' not in result
    assert 'private diagnostic' not in json.dumps(result)
