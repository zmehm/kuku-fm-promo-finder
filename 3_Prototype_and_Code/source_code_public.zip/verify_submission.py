"""Verify current submission deliverables against frozen source artifacts."""
import csv,json
from pathlib import Path
from src import config
from src.schemas import RankedPromo,ParsedEpisode
from src.quality_checker import validate_timestamps,total_duration
from review_tools import cut_sheet

def verify():
    base=config.OUTPUT_DIR/'revised'
    rows=json.loads((base/'ranked/ranked_promos.json').read_text(encoding='utf-8'))
    csvrows=list(csv.DictReader((base/'ranked/ranked_promos.csv').open(encoding='utf-8',newline='')))
    eps={}
    for f in (base/'parsed').glob('episode-*.json'):
        ep=ParsedEpisode.model_validate_json(f.read_text(encoding='utf-8'));eps[ep.episode_number]=ep
    old=json.loads((config.OUTPUT_DIR/'submission_revision_history/ranked_promos_before_description_corrections.json').read_text(encoding='utf-8'))
    assert len(eps)==50 and len(rows)==15 and len(csvrows)==15
    assert sum(ep.total_elements for ep in eps.values())==3727
    sheets={}
    for index,(r,c,previous) in enumerate(zip(rows,csvrows,old),1):
        row=RankedPromo.model_validate(r);p=row.promo
        assert row.rank==index and c['promo_id']==p.promo_id
        assert 20<=total_duration(p)<=60
        assert not validate_timestamps(p,eps)
        sheet=cut_sheet(row,eps);sheets[p.promo_id]=sheet
        assert not sheet['dialogue_crossing_boundaries']
        assert r['scores']==previous['scores'] and r['promo']['segments']==previous['promo']['segments']
        assert c['hook_text']==p.hook and c['cliffhanger_text']==p.cliffhanger and c['posting_rationale']==row.posting_rationale
        assert r['quality_review']['caveat'] and r['quality_review']['unresolved_question'].endswith('?')
        assert p.hook and p.cliffhanger and p.why_it_works and row.posting_rationale
    opens=sheets['PR-027']['first_3_seconds']
    assert any('Get out of the way!' in e['text'] and e['offset_start']==0.6 for e in opens)
    assert any('"No."' in e['text'] and e['offset_start']==2.3 for e in opens)
    assert not any('violently shoves' in e['text'] for e in opens)
    assert not any('Stop this!' in e['text'] for e in sheets['PR-046']['first_3_seconds'])
    assert any('Rupert...' in e['text'] and e['offset_start']==2 for e in sheets['PR-046']['first_3_seconds'])
    assert 'kneels' in rows[13]['promo']['hook']
    assert 'does not address the camera' in rows[12]['promo']['hook']
    assert 'whispering' not in rows[14]['promo']['cliffhanger']
    from pypdf import PdfReader
    pdf=PdfReader(config.OUTPUT_DIR/'Kuku_FM_Solution_Doc.pdf')
    assert len(pdf.pages)==2
    text=' '.join(pg.extract_text() for pg in pdf.pages)
    assert '0/30' not in text and 'optional' in text and 'survived' in text
    result={'status':'passed','episodes':len(eps),'elements':3727,'promos':len(rows),'pdf_pages':len(pdf.pages),'checks':['JSON/CSV parity','all segment timestamps and durations','zero dialogue crossings','scores and cut boundaries preserved','corrected PR-027 and PR-046 source windows','source descriptions and per-promo caveats','human evaluation optional'],'scope':'Offline artifact checks; no fresh full-catalog AI run or audience evaluation.'}
    (config.OUTPUT_DIR/'submission_revision_verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result))
    return result
if __name__=='__main__': verify()
