import csv,io,json
import pytest
from review_tools import import_ratings,human_review_summary,score
from test_review_tools import pack


def returned(reviewer='reviewer_1',pick='A',hook=''):
    text=io.StringIO();writer=csv.DictWriter(text,fieldnames=['reviewer_id','pair_id','overall_pick','hook_pick']);writer.writeheader();writer.writerow({'reviewer_id':reviewer,'pair_id':'P01','overall_pick':pick,'hook_pick':hook})
    return text.getvalue().encode('utf-8')


def test_pending_summary_has_no_invented_wins_and_does_not_write(tmp_path):
    pack(tmp_path,[('A',''),('B',''),('A','')]);(tmp_path/'results.json').write_text('unchanged',encoding='utf-8')
    summary=human_review_summary(tmp_path)
    assert 'pending' in summary and '0/3' in summary
    assert 'pipeline: 0' in summary and 'baseline: 0' in summary
    assert (tmp_path/'results.json').read_text(encoding='utf-8')=='unchanged'


def test_valid_import_backs_up_and_tracks_partial_status(tmp_path):
    pack(tmp_path,[('A',''),('B',''),('A','')]);previous=(tmp_path/'reviewer_1/ratings.csv').read_bytes()
    result=import_ratings(tmp_path,'reviewer_1',returned())
    assert result['status']=='partial' and result['completed_ratings']==1
    backup=list((tmp_path/'private/rating_backups').glob('*.csv'))
    assert len(backup)==1 and backup[0].read_bytes()==previous
    assert len(json.loads((tmp_path/'private/rating_imports.json').read_text()))==1


@pytest.mark.parametrize('data',[b'wrong,headers\na,b\n',returned(pick='Pipeline'),returned(reviewer='reviewer_2'),returned(pick='',hook='invalid')])
def test_invalid_import_never_changes_current_sheet(tmp_path,data):
    pack(tmp_path,[('A','')]);target=tmp_path/'reviewer_1/ratings.csv';before=target.read_bytes()
    with pytest.raises(ValueError): import_ratings(tmp_path,'reviewer_1',data)
    assert target.read_bytes()==before
    assert not (tmp_path/'private/rating_backups').exists()


def test_missing_pair_row_is_rejected(tmp_path):
    pack(tmp_path,[('A','')])
    with pytest.raises(ValueError,match='Missing assigned'):
        import_ratings(tmp_path,'reviewer_1',b'reviewer_id,pair_id,overall_pick\n')


def test_summary_and_protocol_reflect_actual_completed_ratings(tmp_path):
    pack(tmp_path,[('A',''),('B',''),('B','')]);(tmp_path/'protocol.json').write_text('{}',encoding='utf-8')
    for name,choice in [('reviewer_1','A'),('reviewer_2','B'),('reviewer_3','A')]: import_ratings(tmp_path,name,returned(name,choice))
    summary=human_review_summary(tmp_path)
    assert 'complete' in summary and '3/3' in summary
    assert 'pipeline: 2' in summary and 'baseline: 1' in summary
    assert 'pipeline: 1' in summary
    assert json.loads((tmp_path/'protocol.json').read_text())['human_ratings_status']=='complete'


def test_unprepared_review_does_not_create_fake_results(tmp_path):
    assert 'not prepared' in human_review_summary(tmp_path)
    assert not (tmp_path/'results.json').exists()
