"""Quality evidence, balanced development checks, bounded fresh runs and registered inputs.
Commands: suite | fresh | register --script ... --origin ... | registered --record ...
"""
from __future__ import annotations
import argparse,hashlib,json,logging,time,zipfile
from datetime import datetime,timezone
from pathlib import Path
from pydantic import BaseModel
from src import config
from src.clips import fmt_ts
from src.evidence import provenance,audit_evidence
from src.llm_client import GeminiClient,HeuristicClient,PROMPT_VERSION
from src.parser import parse_episode,parse_all_episodes,save_parsed_episodes
from src.pipeline import run_pipeline,save_result
from src.quality_checker import validate_resolution_cues,validate_hook_presence,build_quality_report


def save(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,indent=2),encoding='utf-8')


def scene_text(ending,emotion='Calm',first='Your wedding contract is a lie!',start=0):
    lines=[first,'Let me see the letter.','That signature is not mine.','Someone is standing outside.','We need to decide now.',ending]
    text='EPISODE NUMBER: Episode 903\nEPISODE LOGLINE: A contract dispute.\nSCENE 01\nScene heading: INT. OFFICE - DAY\nScene start: 00:00.00\nScene end: 00:36.00\nActions and dialogue:\n\n'
    for i,line in enumerate(lines):
        text+=f'**LEAD ({emotion}):**\nStart: ({fmt_ts(i*6)}) | End: ({fmt_ts((i+1)*6)})\n"{line}"\n\n'
    return text


def simple_promo(ep):
    from src.schemas import PromoCandidate,PromoSegment
    return PromoCandidate(promo_id='CHECK',promo_type='single_episode',episodes=[ep.episode_number],segments=[PromoSegment(episode=ep.episode_number,start_time='00:00.00',end_time='00:36.00',start_seconds=0,end_seconds=36)],hook='A contract dispute threatens the wedding',cliffhanger='The confrontation leaves the next event unresolved',why_it_works='A conflict is presented with a potentially unresolved ending.')


def confusion(rows):
    tp=sum(r['truth'] and r['detected'] for r in rows);fp=sum(not r['truth'] and r['detected'] for r in rows)
    fn=sum(r['truth'] and not r['detected'] for r in rows);tn=sum(not r['truth'] and not r['detected'] for r in rows)
    return {'true_positive':tp,'false_positive':fp,'false_negative':fn,'true_negative':tn,'precision':round(tp/(tp+fp),3) if tp+fp else None,'recall':round(tp/(tp+fn),3) if tp+fn else None,'false_positive_rate':round(fp/(fp+tn),3) if fp+tn else None,'n':len(rows)}


def suite(out):
    out.mkdir(parents=True,exist_ok=True);inputs=out/'inputs';inputs.mkdir(exist_ok=True)
    endings=[('explicit_safe','We are safe now.',True),('case_closed','The case is closed.',True),('settled','Everything is settled.',True),('forgiven','All is forgiven.',True),('implicit_ring','I found the missing ring under the chair.',True),('implicit_delivery','The parcel arrived. Everyone goes home.',True),('negation','We are not safe now.',False),('question','Is it over?',False),('new_threat','We are safe now. But look behind you!',False),('threatening_over',"It's over for you.",False),('mystery','Who is knocking on that locked door?',False),('condition','Do not open the envelope until I return.',False)]
    closure=[]
    for name,line,truth in endings:
        path=inputs/(name+'.txt');path.write_text(scene_text(line),encoding='utf-8');ep=parse_episode(path)
        flags=validate_resolution_cues(simple_promo(ep),{ep.episode_number:ep})
        closure.append({'case':name,'truth':truth,'detected':bool(flags),'ending':line,'flags':[f.model_dump() for f in flags]})
    hook=[]
    for delay in [0,1,2.99,3,3.2,6]:
        path=inputs/f'hook_{delay}.txt';path.write_text(scene_text('Who is outside?'),encoding='utf-8');ep=parse_episode(path)
        for i,e in enumerate(ep.scenes[0].elements):
            if i==0:
                e.start_seconds=delay;e.start_time=fmt_ts(delay)
                e.end_seconds=delay+5;e.end_time=fmt_ts(delay+5)
        found=bool(validate_hook_presence(simple_promo(ep),{ep.episode_number:ep}))
        hook.append({'case':f'delay_{delay}','truth':delay>=3,'detected':found})
    quiet=['Good morning.','Here is your tea.','Thank you.','Please take a seat.','The weather is mild.','Have a pleasant afternoon.']
    neutral=scene_text(quiet[-1],first=quiet[0])
    for original,new in zip(['Let me see the letter.','That signature is not mine.','Someone is standing outside.','We need to decide now.'],quiet[1:5]): neutral=neutral.replace(original,new)
    cases=[('quiet_neutral',neutral,True),('quiet_misleading_emotions',neutral.replace('(Calm)','(Furious)'),True),('quiet_camera',neutral.replace('**LEAD (Calm):**','**CAMERA:**'),True),('strong_conflict',scene_text('Who is behind that door?',emotion='Furious'),False),('strong_reveal',scene_text('Then whose name is on this marriage certificate?',emotion='Shocked'),False),('strong_threat',scene_text('Do not sign. Someone is waiting outside.',emotion='Desperate'),False)]
    abstention=[]
    for name,text,truth in cases:
        path=inputs/(name+'.txt');path.write_text(text,encoding='utf-8');ep=parse_episode(path)
        result=run_pipeline({ep.episode_number:ep},client=HeuristicClient(),run_baselines=False)
        abstention.append({'case':name,'truth':truth,'detected':not result.ranked,'shortlist_size':len(result.ranked),'status':result.manifest['status']})
    result={'scope':'Authored development suite, not independent held-out data. Labels are authored expectations, not collected human ratings. Precision/recall measure the narrow heuristic, not general creative quality. Misses and false alarms are retained.','closure':{'metrics':confusion(closure),'cases':closure},'delayed_hook':{'metrics':confusion(hook),'cases':hook},'offline_abstention':{'metrics':confusion(abstention),'cases':abstention},'human_ratings_status':'pending','independent_input_status':'pending'}
    save(out/'scorecard.json',result)
    text='# Balanced quality scorecard\n\n'+result['scope']+'\n\n'
    for key in ['closure','delayed_hook','offline_abstention']:
        text+=f"## {key}\n\n{json.dumps(result[key]['metrics'])}\n\n"
        for row in result[key]['cases']:
            if row['truth']!=row['detected']: text+=f"- Miss / false alarm: {row['case']} (expected={row['truth']}, detected={row['detected']})\n"
    (out/'SCORECARD.md').write_text(text,encoding='utf-8')
    return result


class Probe(BaseModel):
    ok:bool


class BoundedClient(GeminiClient):
    def __init__(self,max_calls=400,max_seconds=900):
        super().__init__(use_cache=False)
        self.call_limit=max_calls;self.deadline=time.monotonic()+max_seconds;self.attempted_calls=0;self.blocked_reason=None
    def generate(self,*args,**kwargs):
        if self.blocked_reason: raise RuntimeError('Fresh run stopped: '+self.blocked_reason)
        if self.attempted_calls>=self.call_limit or time.monotonic()>self.deadline:
            self.blocked_reason='call_or_time_budget';raise RuntimeError('Fresh run budget reached')
        self.attempted_calls+=1
        try: return super().generate(*args,**kwargs)
        except Exception as exc:
            text=str(exc)
            if any(x in text for x in ['429','RESOURCE_EXHAUSTED']): self.blocked_reason='api_quota'
            elif any(x in text for x in ['API_KEY_INVALID','PERMISSION_DENIED']): self.blocked_reason='api_credentials'
            raise


def fresh(out):
    if (out/'attempt.json').exists(): raise ValueError('Use a new output folder; earlier evidence is immutable.')
    out.mkdir(parents=True,exist_ok=True)
    config.GEMINI_MAX_RETRIES=1
    files=sorted(config.SCRIPTS_DIR.glob('episode-*.txt'))
    episodes={e.episode_number:e for e in parse_all_episodes(config.SCRIPTS_DIR)}
    proof=provenance(episodes,files);proof['prompt_version']=PROMPT_VERSION;save(out/'provenance.json',proof)
    with zipfile.ZipFile(out/'code_snapshot.zip','w',zipfile.ZIP_DEFLATED) as z:
        root=Path(__file__).resolve().parent
        for name in proof['code_sha256']: z.write(root/name,name)
    client=BoundedClient()
    try:
        if not client.available: raise RuntimeError('No configured API client')
        client.generate('Return JSON with ok=true.',response_schema=Probe)
    except Exception:
        result={'status':'blocked','reason':client.blocked_reason or 'preflight_failed','provenance_fingerprint':proof['fingerprint'],'live_api_usage':client.live_cost_tracker.model_dump(),'attempted_calls':client.attempted_calls,'note':'No historical outputs promoted or relabelled as fresh.'}
        save(out/'attempt.json',result);return result
    original={name:getattr(config,name) for name in ['OUTPUT_DIR','PARSED_DIR','MOMENTS_DIR','PROMOS_DIR','RANKED_DIR','QUALITY_DIR','HUMAN_EVAL_DIR']}
    config.OUTPUT_DIR=out
    for name,folder in [('PARSED_DIR','parsed'),('MOMENTS_DIR','moments'),('PROMOS_DIR','promos'),('RANKED_DIR','ranked'),('QUALITY_DIR','quality_report'),('HUMAN_EVAL_DIR','human_eval')]: setattr(config,name,out/folder)
    def progress(stage,done,total):
        save(out/'progress.json',{'stage':stage,'done':done,'total':total,'attempted_calls':client.attempted_calls,'blocked_reason':client.blocked_reason})
        if done==total: print(f'{stage}: {done}/{total}; API attempts={client.attempted_calls}',flush=True)
    try:
        save_parsed_episodes(list(episodes.values()),config.PARSED_DIR)
        result=run_pipeline(episodes,client=client,run_baselines=True,top_n=30,workers=1,progress=progress)
        initial=list(result.ranked);accepted=[];audits=[]
        for row in initial:
            if len(accepted)>=15: break
            try: evidence=audit_evidence(client,row.promo,episodes)
            except Exception as exc: evidence={'promo_id':row.promo.promo_id,'passed':False,'status':'unavailable','errors':['Audit unavailable: '+(client.blocked_reason or type(exc).__name__)]}
            audits.append(evidence)
            if evidence['passed']:
                row.evidence_audit=evidence;row.rank=len(accepted)+1;accepted.append(row)
        result.ranked=accepted
        comparison=dict(result.report.baseline_comparison)
        comparison['pipeline_final_shortlist']=round(sum(r.scores.composite for r in accepted)/len(accepted),2) if accepted else 0
        result.report=build_quality_report(result.candidates,accepted,result.flags,episodes,baseline_comparison=comparison)
        result.report.honest_limitations.extend(['Final selection includes same-family model evidence review; ID/quote/window validation does not establish semantic truth or human preference.','Development quality scorecards and real human ratings are separate evidence sources.'])
        after=provenance(episodes,files)
        aligned=after['fingerprint']==proof['fingerprint']
        fallbacks=any(result.manifest['fallback_to_heuristic'].values()) or bool(result.manifest.get('critique_failures')) or bool(result.manifest.get('trim_reaudit_failures'))
        status='blocked' if client.blocked_reason else 'code_changed_during_run' if not aligned else 'completed_with_fallbacks' if fallbacks else 'completed'
        result.manifest.update({'validation_mode':'Fresh final-version run, response cache disabled; evidence-gated final shortlist.','provenance_fingerprint':proof['fingerprint'],'prompt_version':PROMPT_VERSION,'initial_shortlist_size':len(initial),'shortlist_size':len(accepted),'evidence_audits':len(audits),'evidence_unavailable':sum(a.get('status')=='unavailable' for a in audits),'evidence_rejections':sum(not a['passed'] and a.get('status')!='unavailable' for a in audits),'run_status':status,'cost':client.cost_tracker.model_dump(),'live_api_usage':client.live_cost_tracker.model_dump(),'cache_hits':client.cache_hits})
        save_result(result);save(out/'evidence_audits.json',audits)
        record={'status':status,'blocked_reason':client.blocked_reason,'code_and_inputs_aligned':aligned,'n_episodes':len(episodes),'shortlist_size':len(accepted),'initial_shortlist_size':len(initial),'evidence_audits':len(audits),'evidence_unavailable':sum(a.get('status')=='unavailable' for a in audits),'evidence_rejections':sum(not a['passed'] and a.get('status')!='unavailable' for a in audits),'cache_hits':client.cache_hits,'live_api_usage':client.live_cost_tracker.model_dump(),'attempted_calls':client.attempted_calls,'fallbacks':result.manifest['fallback_to_heuristic'],'note':'Actual final-version outputs; no claim of independent human or unseen-show validation.'}
        save(out/'attempt.json',record)
        return record
    finally:
        for name,value in original.items(): setattr(config,name,value)


def register(script,out,origin):
    if out.exists(): raise ValueError('Registration already exists; do not overwrite a preregistered challenge.')
    ep=parse_episode(script)
    record={'status':'registered_not_run','script':str(script.resolve()),'input_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'origin_claim':origin,'independence':'Self-reported provenance; not independently authenticated. Development input is not held-out evidence.','protocol':'Freeze input and current core code before one uncached run. Retain rejection and fallback outcomes; do not retune on the challenge and call it held-out.','proof':provenance({ep.episode_number:ep},[script])}
    save(out,record);return record


def registered(record_path,out):
    from review_tools import unseen
    record=json.loads(record_path.read_text(encoding='utf-8'));script=Path(record['script']);ep=parse_episode(script)
    current=provenance({ep.episode_number:ep},[script])
    if current['fingerprint']!=record['proof']['fingerprint']: raise ValueError('Registered input, core code or runtime configuration changed. Freeze a new challenge; do not treat this as the original holdout.')
    result=unseen(script,out,'ai')
    if result.get('ranked'):
        from src.schemas import RankedPromo
        client=BoundedClient(max_calls=20,max_seconds=120)
        accepted=[];audits=[]
        for raw in result['ranked']:
            row=RankedPromo.model_validate(raw)
            try: audit=audit_evidence(client,row.promo,{ep.episode_number:ep})
            except Exception as exc: audit={'promo_id':row.promo.promo_id,'passed':False,'status':'unavailable','errors':[client.blocked_reason or type(exc).__name__]}
            audits.append(audit)
            if audit['passed']:
                row.evidence_audit=audit;row.rank=len(accepted)+1;accepted.append(row.model_dump())
        result['pre_evidence_ranked']=result['ranked'];result['ranked']=accepted;result['evidence_audits']=audits
        result['evidence_api_usage']=client.live_cost_tracker.model_dump()
        if not accepted: result['status']='evidence_unavailable' if any(a.get('status')=='unavailable' for a in audits) else 'no_evidence_verified_recommendation'
    result['registered_challenge']=record
    result['independence_note']='Declared origin is retained, not independently authenticated. Retry limits are an explicit runner override recorded in actual run provenance.'
    save(out/'result.json',result)
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='command',required=True)
    for name in ['suite','fresh']:
        command=sub.add_parser(name);command.add_argument('--out',type=Path,required=True)
    command=sub.add_parser('register');command.add_argument('--script',type=Path,required=True);command.add_argument('--out',type=Path,required=True);command.add_argument('--origin',choices=['development','evaluator-supplied','independent-author'],required=True)
    command=sub.add_parser('registered');command.add_argument('--record',type=Path,required=True);command.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    if args.command=='suite': result=suite(args.out)
    elif args.command=='fresh': result=fresh(args.out)
    elif args.command=='register': result=register(args.script,args.out,args.origin)
    else: result=registered(args.record,args.out)
    if args.command=='suite': result={name:data['metrics'] for name,data in result.items() if isinstance(data,dict) and 'metrics' in data}
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
