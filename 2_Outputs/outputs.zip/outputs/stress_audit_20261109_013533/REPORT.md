# Stress audit

Offline stress tests and isolated packaged-app executions. No fresh API calls; unavailable API was simulated. No human quality or ad-conversion validation.

Passed: 28. Failed: 13.

- **PASS regression_suite**: exit=0; see regression_suite.log
- **PASS parser_valid_original**: accepted 8 elements; nonpositive intervals=0; expected complete parse
- **PASS parser_valid_crlf**: accepted 8 elements; nonpositive intervals=0; expected complete parse
- **PASS parser_valid_bom**: accepted 8 elements; nonpositive intervals=0; expected complete parse
- **PASS parser_valid_comma**: accepted 8 elements; nonpositive intervals=0; expected complete parse
- **PASS parser_valid_one_decimal**: accepted 8 elements; nonpositive intervals=0; expected complete parse
- **PASS parser_valid_three_decimals**: accepted 8 elements; nonpositive intervals=0; expected complete parse
- **PASS parser_valid_aliases**: accepted 8 elements; nonpositive intervals=0; expected complete parse
- **PASS parser_empty**: ValueError: No script elements parsed from empty.txt: check the timestamp/format
- **PASS parser_prose**: ValueError: No script elements parsed from prose.txt: check the timestamp/format
- **PASS parser_header_only**: ValueError: No script elements parsed from header_only.txt: check the timestamp/format
- **PASS parser_unsupported_header**: ValueError: Unsupported timed element header at line 8: **Captain [Mira]:**. Adapt the screenplay format before extraction.
- **FAIL parser_inverted_element**: accepted 8 elements; nonpositive intervals=1; expected explicit rejection
- **FAIL parser_zero_length_element**: accepted 8 elements; nonpositive intervals=1; expected explicit rejection
- **FAIL parser_seconds_out_of_range**: accepted 8 elements; nonpositive intervals=0; expected explicit rejection
- **FAIL parser_malformed_timed_block**: accepted 7 elements; nonpositive intervals=0; expected explicit rejection
- **FAIL parser_missing_timed_block**: accepted 7 elements; nonpositive intervals=0; expected explicit rejection
- **FAIL parser_duplicate_episode**: accepted 16 elements; nonpositive intervals=0; expected explicit rejection
- **FAIL invalid_timestamp_00:60.00**: Accepted as 00:60.00; seconds must be 00-59
- **FAIL invalid_timestamp_00:99.00**: Accepted as 00:99.00; seconds must be 00-59
- **FAIL invalid_timestamp_99:99.99**: Accepted as 99:99.99; seconds must be 00-59
- **PASS timestamp_fuzz_1000**: 1000/1000 valid centisecond strings preserved
- **PASS catalog_timestamp_integrity**: 104 candidate/ranked entries checked; candidate issues=1, ranked issues=0
- **PASS ranked_dialogue_boundary_crossings**: 0/15 shortlisted promos cross dialogue boundaries
- **FAIL validator_string_numeric_consistency**: A numeric 0s start labelled 00:12.00 must be flagged
- **FAIL validator_repeated_internal_segment**: Same 0-24s segment repeated twice should be detected, not treated as a novel 48s promo
- **PASS validator_unknown_episode**: Unknown episode 999 flagged
- **FAIL long_dialogue_judge_visibility**: A critical reveal after 400 characters is truncated in the default scoring renderer
- **PASS offline_catalog_workers_1**: 50 episodes; 114 candidates; 15 shortlisted; 0.121s
- **PASS offline_catalog_workers_4**: 50 episodes; 114 candidates; 15 shortlisted; 0.114s
- **PASS offline_concurrency_stability**: 1 vs 4 workers; timings={'1': 0.121, '4': 0.114}
- **PASS offline_repeat_stability_20**: 20 repeated offline runs compared
- **PASS unavailable_api_fallback**: Shortlisted 1; fallbacks={'moments': [901], 'construction': [901], 'scoring': ['PR-001']}; critique failures=['PR-001']
- **FAIL rule_adversarial_detection**: Caught 3/4 known bad cases; details in legacy_checks.log
- **PASS blind_review_content_integrity**: Exact pipeline source text verified in 3 handouts; pair counts=[10, 10, 10]
- **PASS packaged_private_dashboard**: exit=0; see packaged_private_dashboard.log
- **PASS packaged_private_offline**: exit=0; see packaged_private_offline.log
- **PASS packaged_public_dashboard**: exit=0; see packaged_public_dashboard.log
- **PASS packaged_public_offline**: exit=0; see packaged_public_offline.log
- **PASS combined_zip_integrity**: 24 outer entries checked
- **PASS submission_evidence_unchanged**: SHA-256 comparison of manifests, ranked output, reviewer ratings/results and combined ZIP